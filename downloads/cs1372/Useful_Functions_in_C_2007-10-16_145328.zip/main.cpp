#include <stdio.h>
#include <malloc.h>

#include "strutil.h"

int main(int argc, char **argv)
{
  char *str = "   This is a long string with spaces on the ends. ";
  char *p = trim(str);
  
  int pieces;
  char **list;
  pieces = slice(p, " rd", &list);
  free(p);
  
  for (char **i = list; *i; ++i)
    printf("Word %-2d: \"%s\"\n", i-list, *i);

  clean(&list);
  return 0;
}