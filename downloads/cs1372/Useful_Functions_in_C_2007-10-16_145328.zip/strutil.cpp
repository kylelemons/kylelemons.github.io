#include <malloc.h>
#include <string.h>
#include <ctype.h>

char *trim(const char *input)
{
  const char *b, *e;
  char *o;
  b = input;
  e = input + strlen(input);
  while (isspace(*b))     ++b;
  while (isspace(*(e-1))) --e;
  o = (char*)calloc(e-b+1, sizeof(char));
  memcpy(o, b, e-b);
  return o;
}

int slice(const char *input, const char *delims, char** *output)
{
  int size = 0;
  char **list = (char**)calloc(size+1, sizeof(char*));
  
  const char *p = input;
  const char *b = input;
  do
  {
    if (strchr(delims, *p) != NULL)
    {
      ++size;
      char *s = (char*)calloc(p-b+1, sizeof(char));
      memcpy(s, b, p-b);
      list = (char**)realloc(list, (size+1)*sizeof(char*));
      list[size-1] = s;
      list[size] = NULL;
      b = p+1;
    }
  } while (*(p++));
  *output = list;
  return size;
}

void clean(char** *list)
{
  char **p = *list;
  while (*p) free(*(p++));
  free(*list);
  *list = NULL;
}