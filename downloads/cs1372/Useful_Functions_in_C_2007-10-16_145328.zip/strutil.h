#ifndef _STRUTIL
#define _STRUTIL

/**
 *  This function duplicates the whitespace-trimmed version of a string.
 * Characters eligible for trimming include all those for whom ::isspace()
 * is true.
 */
char *trim(const char *input);

/**
 *  This function allocates and stores in the char** pointed to by list an
 * array of char*s which correspond to (also allocated) duplicates of the
 * tokens in input, separated by any character in delims.  It returns the
 * number of pieces that it split the string into.  The list is also NULL
 * terminated.
 */
int slice(const char *input, const char *delims, char** *list);

/**
 *  This function cleans up a list created by slice (or created identicaly)
 * by freeing the individual strings and then the list itself, and assigning
 * the list pointer to NULL to prevent misuse.
 */
void clean(char** *list);

#endif