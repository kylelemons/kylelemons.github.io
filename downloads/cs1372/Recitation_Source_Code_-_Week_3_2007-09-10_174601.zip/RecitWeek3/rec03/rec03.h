//reco3.h

void conditional(double x, double y);
void loopwhile(int x);
void loopfor(int x);