#include <stdio.h>
#include "rec03.h"

void main()
{
	conditional(2.8, 3.8);
	//loopwhile(6);
	//loopfor(6);
	//getchar();
}
