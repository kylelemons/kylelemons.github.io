#include <stdio.h>
#include <math.h>
#include "rec03.h"

void conditional(double x, double y)
{
  int i;
  printf("%d\n", i);
	if(abs(x-y)<1)
	{
		printf("They are nearly equal, x=%.1f, y=%.1f\n", x, y);
	}
	else if(x<y)
	{
		printf("y is greater, y=%f\n", y);
	}
	else 
	{
		printf("x is greater, x=%f\n", x);
	}
}

void loopwhile(int x)
{
	int i = 0;
	while (i<x)
	{
		printf("i=%d\t", i);
		i++;
	}
	printf("\n");
}

void loopfor(int x)
{
	for(int i=0 ; i<x ; i++)
	{
		printf("i=%d\t", i);
	}
}