void getMaxMin(char *str, char *largest, char *smallest, unsigned *lindex, unsigned *sindex)
{
  char *p = str;
  *smallest = '\0'; // this needed the * at the beginning
  *largest = '\0'; // this needed the * as well

  while (*p)
  {
    char c = *p;
    if (smallest == '\0')
    {
      *smallest = c;
      *largest = c;
      *sindex = 0;
      *lindex = 0;
    }

    if (c < *smallest)
    {
      *smallest = c;
      *sindex = p - str;
    }

    if (c > *largest)
    {
      *largest = c;
      *lindex = p - str;
    }

    ++p;
  }
}