#ifndef STRSTUFF_H
#define STRSTUFF_H

void getMaxMin(char *str, char *largest, char *smallest, unsigned *lindex, unsigned *sindex);

#endif /* STRSTUFF */