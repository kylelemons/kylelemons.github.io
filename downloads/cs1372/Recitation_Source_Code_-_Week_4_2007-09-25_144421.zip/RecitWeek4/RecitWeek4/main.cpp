#include <stdio.h>

#include "strstuff.h"

int main(int argc, char **argv)
{
  char s, l;
  unsigned lindex, sindex;
  getMaxMin("CS1372 is cool", &l, &s, &lindex, &sindex);

  printf("CS1372 is cool:\n");
  printf("Smallest: %c @ %ud\n", s, sindex);
  printf("Largest:  %c @ %ud\n", l, lindex);

  return 0;
}