#ifndef GRAPH_H
#define GRAPH_H

#include <vector>

#include "GL/glut.h"		/* Header file for the GLut library */

using namespace std;

#include "vector.h"
#include "point.h"
#include "plot.h"

#ifndef PI
#define PI 3.14159265358979323846264338327950288
#endif

//#define GRAPH_LIB // suppress main() method

class Graph
{
  public:
    static int    g_argc;
    static char **g_argv;
    typedef enum {
      GRAPH_ORTHO,
      GRAPH_AUTOSCALE,
      GRAPH_ANIMATING,
      GRAPH_FULLSCREEN
    } graph_flag;
    typedef enum {
      MENU_QUIT, 
      MENU_FULLSCREEN, 
      MENU_ANIMATE, 
      MENU_VIEW_RESET,
      MENU_ORTHOGRAPHIC,
      MENU_ORTHO_FRONT,
      MENU_ORTHO_RIGHT,
      MENU_ORTHO_TOP,
      MENU_ORTHO_BACK,
      MENU_ORTHO_LEFT,
      MENU_ORTHO_BOTTOM,
      MENU_CHOOSE_0,
      MENU_CHOOSE_1,
      MENU_CHOOSE_2,
      MENU_CHOOSE_3,
      MENU_CHOOSE_4,
      MENU_CHOOSE_5,
      MENU_CHOOSE_6,
      MENU_CHOOSE_7,
      MENU_CHOOSE_8,
      MENU_CHOOSE_9,
      MENU_CHOOSE_ALL,
      MENU_DISP_COLOR,
      MENU_DISP_SHADE,
      MENU_DISP_SOLID,
      MENU_SURF_POINT,
      MENU_SURF_LINES,
      MENU_SURF_SURFS
    } graph_menu;

  private:
    typedef Point<GLdouble> point;
    typedef Point<int>      cursor;
    typedef int             mode;
    typedef bool            flag;

    // Statics
    static int s_graph_count;// = 0;
    static GLfloat  s_light_position[];// = {   5,  15,  10,   0 };
    static GLfloat  s_light_color[];//    = {   1,   1,   1,   1 };
    static GLclampf s_clear_color[];//    = { 1.0, 1.0, 1.0, 1.0 };
    static int      s_display_mode;// = GLUT_DOUBLE|GLUT_RGBA|GLUT_DEPTH;

    // Variables
    int      m_win_id;
    string   m_graph_name;
    int      m_window_width;
    int      m_window_height;
    int      m_anim_delay;
    GLdouble m_near_clipping_plane;
    GLdouble m_far_clipping_plane;
    point    m_look_from;
    point    m_look_at;
		point		 m_up;
    point    m_view_rotation;
    point    m_view_translation;
    cursor   m_mouse_position;
    cursor   m_window_position;
    mode     m_draw_mode; // GL_POINTS, GL_LINES, GL_TRIANGLES
    flag     m_fullscreen;
    flag     m_animating;
    flag     m_orthographic;
		flag		 m_autoscale;
    flag     m_display_enabled;
    char     m_ortho_mode;
    point    m_ortho_view;
    point    m_trackball_lastpoint;
    GLfloat  m_trackball_transform[16];

    vector< Plot > m_plot;

    // OpenGL stuff (not accessible to the outside world!)
    void init_opengl();
    void fini_opengl();

  private:
    // These are for the Trackball Thingamajigger(TM)
    inline void calcAngle(GLfloat *newMatrix, GLfloat angle, point a);
    inline point spherePoint(GLint mx, GLint my);
    void trackball(int mx, int my);

  public:
    Graph(bool enabled = true);
   ~Graph();

    void display();
    void resize(int, int);
    void keyboard(unsigned char, int, int);
    void click(int, int, int, int);
    void drag(int, int, unsigned modifiers);
    void menu(int);
    void timer();
    void draw();
    void axes();
    void loop();

    // Plot Management
    int   add(const Plot &new_plot);
    void  del(int plot_id);
    Plot &get(int plot_id);
    Plot &operator[](int plot_id);

    void  enable(graph_flag gfFlag);
    void  disable(graph_flag gfFlag);
    bool  enabled(graph_flag gfFlag);

    // modifier
    void reverse_normals();

    // Dump to "<filename>-plot#.<extension>"
    void dump(const char *filename, const char *extension = "csv");

    // Accessors
    int win_id();
};

extern vector<Graph*> g_graph_pointers;

// OpenGL Function Prototypes
extern "C" void start_opengl_loop();
extern "C" void handle_opengl_display();
extern "C" void handle_opengl_resize(int new_width, int new_height);
extern "C" void handle_opengl_keyboard(unsigned char key, int x, int y);
extern "C" void handle_opengl_click(int button, int state, int x, int y);
extern "C" void handle_opengl_drag(int x, int y);
extern "C" void handle_opengl_timers(int timerid);
extern "C" void handle_opengl_menu(int menuid);
extern "C" void handle_opengl_destroy(); // call this whenever something should kill the program so that we can clean up

void demo_peaks(const GLdouble &x, const GLdouble &y, const GLdouble &ignored, GLdouble &fx, GLdouble fy, GLdouble &fz); // reconnended: x:[-2pi,2pi] y:[-2pi,2pi] z:[0,0]
void demo_sphere(const GLdouble &theta, const GLdouble &alpha, const GLdouble &ignored, GLdouble &fx, GLdouble fy, GLdouble &fz); // recommended: x:[0,pi] y:[-pi,pi] z:[0,0]
void demo_revolve(const GLdouble &x, const GLdouble &theta, const GLdouble &ignored, GLdouble &fx, GLdouble fy, GLdouble &fz); // recommended: x:[-pi,pi] y:[-pi,pi] z:[0,0]

#endif
