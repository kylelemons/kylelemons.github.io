#ifndef VECTOR_H
#define VECTOR_H

/*
 * Kyle Lemons
 * Februry 2006
 * This code is licensed under the GNU GPL v2
 */

#include <vector>
#include <numeric>
#include <sstream>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cassert>
#include <cmath>
using namespace std;

template <typename T, int COMPONENTS = 3>
class Vector
{
  public:
    typedef Vector<T,COMPONENTS> vector_type;

  private:
    T *components;

    void allocate()
    {
      //cout << "Allocating...   " << flush;
      components = (T*)calloc(COMPONENTS, sizeof(T));
      //cout << hex << components << endl;
    }

    void deallocate()
    {
      //cout << "Deallocating... " << hex << components << endl;
      if (components)
        free(components);
      components = NULL;
    }

    void assign_from(const vector_type &other)
    {
      for (int i = 0; i < COMPONENTS; ++i)
        components[i] = other.components[i];
    }

  public:
    // Static Constants
    
    static const T i_unit[];
    static const T j_unit[];
    static const T k_unit[];

    // Functions

    Vector(int initial_value = 0);
    Vector(const T components[]);

    Vector(const Vector<T,COMPONENTS> &other) { allocate(); assign_from(other); }
   ~Vector() { deallocate(); };

    const vector_type &operator=(const Vector<T,COMPONENTS> &other);// { deallocate(); allocate(); assign_from(other); }

    T            dot(const Vector<T,COMPONENTS> &other) const;
    vector_type  cross(const Vector<T,COMPONENTS> &other) const;
    T            magnitude() const;
    vector_type  normalize();

    vector_type  operator-() const; // unary negation
    T            operator*(const vector_type &other) const; // dot product
    vector_type  operator^(const vector_type &other) const; // cross product
    vector_type  operator+(const vector_type &other) const; // component addition
    const vector_type &operator+=(const vector_type &other) const; // component addition
    
    operator double() const; // magnitude
    operator float() const;
    operator int() const;

    T           &operator[](const int dimension) const;
    const vector_type &operator=(T arr[]);

    // Scalar math operators
    vector_type operator*(const T &other) const;
    vector_type operator/(const T &other) const;

    // comparison operators
    bool operator==(const vector_type other) const;
    bool operator<(const vector_type other) const;

    void zero();

    string to_string() const;
};

template <typename T, int COMPONENTS>
const T Vector<T,COMPONENTS>::i_unit[] = {1,0,0};

template <typename T, int COMPONENTS>
const T Vector<T,COMPONENTS>::j_unit[] = {0,1,0};

template <typename T, int COMPONENTS>
const T Vector<T,COMPONENTS>::k_unit[] = {0,0,1};

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS>::Vector(int ival)
{
  components = NULL;
  allocate();
  for (int i = 0; i < COMPONENTS; ++i) components[i] = ival;
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS>::Vector(const T icomponents[]) : components(COMPONENTS)
{
  components = NULL;
  allocate();
  for (int i = 0; i < COMPONENTS; ++i) components[i] = icomponents[i];
}

template <typename T, int COMPONENTS>
T Vector<T,COMPONENTS>::dot(const Vector<T,COMPONENTS> &other) const
{
  T ret = (T)0;
  for (int i = 0; i < COMPONENTS; ++i)
  {
    ret += components[i] * other.components[i];
  }
  return ret;
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::cross(const Vector<T,COMPONENTS> &other) const
{
  Vector<T,COMPONENTS> ret(COMPONENTS);
  for (int i = 0; i < COMPONENTS; ++i)
  {
    int j,k;
    j = (i + 1) % COMPONENTS;
    k = (j + 1) % COMPONENTS;
    ret[i] = components[j] * other.components[k] - components[k] * other.components[j];
  }
  return ret;
}

template <typename T, int COMPONENTS>
T Vector<T,COMPONENTS>::magnitude() const
{
  T sum = (T)0;
  for (int i = 0 ; i < COMPONENTS ; ++i)
    sum += components[i] * components[i];
  return (T)sqrt((double)sum);
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::normalize()
{
  T mag = magnitude();
  if (mag)
    for (int i = 0; i < COMPONENTS; ++i)
      components[i] /= mag;
  return *this;
}

template <typename T, int COMPONENTS>
T Vector<T,COMPONENTS>::operator*(const Vector<T,COMPONENTS> &other) const
{
  return dot(other);
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::operator^(const Vector<T,COMPONENTS> &other) const
{
  return cross(other);
}

template <typename T, int COMPONENTS>
T &Vector<T,COMPONENTS>::operator[](const int dimension) const
{
  assert(dimension >= 0 && dimension < COMPONENTS);
  return components[dimension];
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS>::operator double() const
{
  return magnitude();
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS>::operator float() const
{
  return (float)magnitude();
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS>::operator int() const
{
  return (int)magnitude();
}

template <typename T, int COMPONENTS>
const Vector<T,COMPONENTS> &Vector<T,COMPONENTS>::operator=(const Vector<T,COMPONENTS> &other)
{
  deallocate();
  //cout << "assign const." << endl;
  allocate();
  assign_from(other);
  return *this;
}

template <typename T, int COMPONENTS>
const Vector<T,COMPONENTS> &Vector<T,COMPONENTS>::operator=(T arr[])
{
  deallocate();
  cout << "arr[] const." << endl;
  allocate();
  for (int i = 0 ; i < COMPONENTS ; ++i)
  {
    components[i] = arr[i];
  }
  return *this;
}

// Typical math operators
template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::operator-() const
{
  Vector<T,COMPONENTS> value(COMPONENTS);
  for (int i = 0; i < COMPONENTS; ++i)
    value.components[i] = components[i] * -1;
  return value;
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::operator+(const Vector<T,COMPONENTS> &other) const
{
  Vector<T,COMPONENTS> value(COMPONENTS);
  for (int i = 0; i < COMPONENTS; ++i)
    value.components[i] = components[i] + other.components[i];
  return value;
}

template <typename T, int COMPONENTS>
const Vector<T,COMPONENTS> &Vector<T,COMPONENTS>::operator+=(const Vector<T,COMPONENTS> &other) const
{
  for (int i = 0; i < COMPONENTS; ++i)
    components[i] = components[i] + other.components[i];
  return *this;
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::operator*(const T &other) const
{
  Vector<T,COMPONENTS> value(COMPONENTS);
  for (int i = 0; i < COMPONENTS; ++i)
    value.components[i] = components[i] * other;
  return value;
}

template <typename T, int COMPONENTS>
Vector<T,COMPONENTS> Vector<T,COMPONENTS>::operator/(const T &other) const
{
  Vector<T,COMPONENTS> value(COMPONENTS);
  for (int i = 0; i < COMPONENTS; ++i)
    value.components[i] = components[i] / other;
  return value;
}

// Comparison operators
template <typename T, int COMPONENTS>
bool Vector<T,COMPONENTS>::operator==(const Vector<T,COMPONENTS> other) const
{
  bool result = true;
  for (int i = 0; i < COMPONENTS; ++i)
    result &= components[i] == other.components[i];
  return result;
}

template <typename T, int COMPONENTS>
bool Vector<T,COMPONENTS>::operator<(const Vector<T,COMPONENTS> other) const
{
  return (magnitude() < other.magnitude());
}

template <typename T, int COMPONENTS>
void Vector<T,COMPONENTS>::zero()
{
  for (int i = 0; i < COMPONENTS; ++i)
    components[i] = (T)0.0;
}

template <typename T, int COMPONENTS>
string Vector<T,COMPONENTS>::to_string() const
{
  string comma = "";
  stringstream ret;
  ret << "<";
  for (int i = 0; i < COMPONENTS; ++i)
  {
    ret << comma;
    ret << components[i];
    comma = ",";
  }
  ret << ">";
  return ret.str();
}

/*
template <typename T, int COMPONENTS>
Vector<T,COMPONENTS>::operator T[]()
{
  static T *temp = calloc(components.size(),sizeof(T))
  for (int i = 0; i < components.size(); ++i)
    (temp+i) = components[i];
  return temp;
}
*/

template <typename T, int COMPONENTS>
ostream &operator<<(ostream &out, const Vector<T,COMPONENTS> v)
{
  return out << v.to_string();
}

#endif /* VECTOR_H */
