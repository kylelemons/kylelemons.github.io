#ifndef _MERROR_H_
#define _MERROR_H_
#include <stdio.h>

// Error codes
enum merrors {MERR_OK,
			  MERR_NOMEM,
			  MERR_INVALID,
			  MERR_PARSE,
			  MERR_SIZE,
			  MERR_DIV};

//Global error storage thingy, acts like errno
extern int merror;

// Error code strings

static char* errstr[] = {"OK.",
						 "Out of memory.",
						 "Invalid vector/matrix.",
						 "Error parsing vector/matrix data.",
						 "Size mismatch.",
						 "Attempted division by zero."};

//Function to print the current value of merror as
//a string. prints: "str: error string"
void error(FILE* stream, char* str);

#endif