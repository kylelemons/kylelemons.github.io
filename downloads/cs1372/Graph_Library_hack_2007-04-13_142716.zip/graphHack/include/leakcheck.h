#ifndef LEAKCHECK_H
#define LEAKCHECK_H

void leakcheck();

#endif
