#ifndef CGRAPH_H
#define CGRAPH_H

#include "graph.h"

#ifdef _WIN32

  #pragma comment(lib, "matrixLib.lib")

  #include "matrix.h"

  #define buildvector(x) zeros(x)
  #define buildmatrix(x,y) zeros(x,y)

  #undef _CHEAT_VECTOR_LIB
#endif

#ifdef _CHEAT_VECTOR_LIB
  #define mindex(m,r,c) (m.data[r][c])

  typedef struct {
    int length;
    double *data;
  } sVector;

  sVector buildvector( int size );
  void vfree(sVector &vVictim);
  
  typedef struct {
    int rows;
    int cols;
    double **data;
  } sMatrix;

  sMatrix buildmatrix( int rows, int cols );
  void mfree(sMatrix &mVictim);
#endif

#ifndef _NO_GRAPHING

// Always call this first!
#define PLOT_START(argc,argv) \
  Graph::g_argc = argc; \
  Graph::g_argv = argv; \
  init_plot(true);

#define PLOT_RUN() \
  run_plot();

#else

#define PLOT_START(argc,argv) \
  Graph::g_argc = argc; \
  Graph::g_argv = argv; \
  init_plot(false);

#define PLOT_RUN() \
  dump_graph("graph");

#endif

void init_plot(bool enabled = true);
void fini_plot();
void run_plot();

void plot(sVector vX, sVector vY);
void plot(sVector vX, sVector vY, sVector vZ);
void surf(sMatrix mX, sMatrix mY, sMatrix mZ);

void showoff(int resolution = 3); // 3 is okay, 6 is good... only use higher at your peril

void dump_graph(const char *filename);

#endif
