#ifndef POINT_H
#define POINT_H

#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
using namespace std;

#include "vector.h"

#define SIGN(x) ((x<0)?-1:1)
#define MIN_DOUBLE_DIFF 1e-10

//
// Point class
//  : A collection of T's
template <typename T>
class Point
{
  public:
    const static int i = 0;
    const static int j = 1;
    const static int k = 2;

  private:
    T x0,y0,z0;
  
  public:
    T x,y,z;
    T mass;
    Vector<T> force;
    Vector<T> velocity;

  public:
    Point() : x0(0), y0(0), z0(0), x(0), y(0), z(0), mass(0) {}
    Point(T _x, T _y, T _z = T(0), T _mass = (T)1) : x0(_x), y0(_y), z0(_z), x(_x), y(_y), z(_z), mass(_mass)
    {}

    bool operator==(const Point<T> other) const
    {
      return (abs(x - other.x) < MIN_DOUBLE_DIFF &&
              abs(y - other.y) < MIN_DOUBLE_DIFF &&
              abs(z - other.z) < MIN_DOUBLE_DIFF);
    }

    Point<T> operator+(const Vector<T> vec) const
    {
      Point<T> point;
      point.x = x + vec[i];
      point.y = y + vec[j];
      point.z = z + vec[k];
      return point;
    }

    Vector<T> operator-(const Point<T> other) const
    {
      Vector<T> result(3);
      result[i] = x - other.x;
      result[j] = y - other.y;
      result[k] = z - other.z;
      return result;
    }

    Point<T> operator*(double scalar) const
    {
      Point<T> np;
      np.x = x * scalar;
      np.y = y * scalar;
      np.z = z * scalar;
      return np;
    }

    Point<T> operator*=(double scalar)
    {
      x *= scalar;
      y *= scalar;
      z *= scalar;
    }

    T &operator[](int dir) const
    {
      switch (dir)
      {
        case i: return x; break;
        case j: return y; break;
        case k: return z; break;
      }
      return z; // *shrug* what else could I do?
    }

    double distance()
    {
      return sqrt(x*x + y*y + z*z);
    }

    string to_string() const
    {
      stringstream ss;
      ss << "(" << x << "," << y << "," << z << ")";
      return ss.str();
    }

    operator string() const
    {
      return to_string();
    }

    // bx, by, and bz represent the boundary point that the point hit.
    // normal represents the surface normal at that point.
    void bounce(T x_0, T y_0, T z_0, Vector<T> normal)
    {
      //T extra_x = (T)0, extra_x_time = (T)0, extra_x_velocity = (T)0;
      //T extra_y = (T)0, extra_y_time = (T)0, extra_y_velocity = (T)0;
      //T extra_z = (T)0, extra_z_time = (T)0, extra_z_velocity = (T)0;

      /* WORKS.  SAVE.
      T delta_t = (y - y_0) / velocity[1];
      T v_0 = velocity[1] - delta_t * force[1]/mass;
      T v_1 = (-v_0 * normal[1]) + delta_t * force[1]/mass;
      T y_1 = y_0 + v_1 * delta_t;
      y = y_1;
      velocity[1] = v_1;
      */
      
      // Note, at the moment, this only works in the Y direction, and only with negative initial velocities.
      T dt_x = (velocity[0]!=(T)0)?((x - x_0) / velocity[0]):0;
      T dt_y = (velocity[1]!=(T)0)?((y - y_0) / velocity[1]):0;
      T dt_z = (velocity[2]!=(T)0)?((z - z_0) / velocity[2]):0;
      T v0_x = velocity[0] - dt_x * force[0]/mass;
      T v0_y = velocity[1] - dt_y * force[1]/mass;
      T v0_z = velocity[2] - dt_z * force[2]/mass;
      velocity[0] = (-v0_x * normal[0]) + dt_x * force[0]/mass;
      velocity[1] = (-v0_y * normal[1]) + dt_y * force[1]/mass;
      velocity[2] = (-v0_z * normal[2]) + dt_z * force[2]/mass;
      x = x_0 + SIGN(normal[0]) * abs(velocity[0] * dt_x);
      y = y_0 + SIGN(normal[1]) * abs(velocity[1] * dt_y);
      z = z_0 + SIGN(normal[2]) * abs(velocity[2] * dt_z);

      /*
      // Calculate what happened after the real colliion
      extra_x = abs(x - bx);
      extra_y = abs(y - by);
      extra_z = abs(z - bz);
      if (velocity[i] != 0) extra_x_time = extra_x / velocity[i];
      if (velocity[j] != 0) extra_y_time = extra_y / velocity[j];
      if (velocity[k] != 0) extra_z_time = extra_z / velocity[k];
      extra_x_velocity = force[i]/mass * extra_x_time;
      //extra_y_velocity = force[j]/mass * extra_y_time;
      extra_y_velocity = force[j]/mass * extra_y_time;
      extra_z_velocity = force[k]/mass * extra_z_time;

      x = bx + extra_x; //+ extra_x_velocity * extra_x_time;
      //cout << "y_i = " << y << ", " << flush;
      y = by + extra_y_velocity * extra_y_time;
      //cout << "y = "<<by<<"+"<<force[j]<<"/"<<mass<<"*"<<extra_y<<"/"<<velocity[j]<<"*"<<extra_y<<"/"<<velocity[j]<<flush;
      //cout << " = " << y << endl;
      //cout << "y_i+1 = " << y << endl;
      //cout <<by<<" + "<<(force[j]/mass)<<" * "<<extra_y_time<<" * "<<extra_y / velocity[j]<<" = "<<y<<endl;
      z = bz + extra_z; //+ extra_z_velocity * extra_z_time;

      // Figure the velocity added by forces which
      //  were acting while this point while it
      //  has been beyond the boundary point
      // take it out
      velocity[i] += extra_x_velocity;
      velocity[j] += extra_y_velocity;
      velocity[k] += extra_z_velocity;
      // reflect the velocity based on the normal
      velocity[i] *= SIGN(normal[i]) * SIGN(velocity[i]) * normal[i];
      velocity[j] *= SIGN(normal[j]) * SIGN(velocity[j]) * normal[j];
      velocity[k] *= SIGN(normal[k]) * SIGN(velocity[k]) * normal[k];
      // account for the velocity where it should've been
      velocity[i] -= extra_x_velocity;
      velocity[j] -= extra_y_velocity;
      velocity[k] -= extra_z_velocity;
      */
    }

    void apply_forces(T dt)
    { // Simple Euler integration
      velocity += force * dt;
      x += velocity[i] * dt;
      y += velocity[j] * dt;
      z += velocity[k] * dt;
    }

    void set_mass(T mass) const
    {
      this->mass = mass;
    }

    void reset()
    {
      x = x0;
      y = y0;
      z = z0;
      velocity = Vector<T>(0);
      force = Vector<T>(0);
    }

    void reset(T _x, T _y, T _z, T _mass = 1)
    {
      x = x0 = _x;
      y = y0 = _y;
      z = z0 = _z;
      velocity = Vector<T>(0);
      force = Vector<T>(0);
    }

    void data(T *x, T *y, T *z)
    {
      *x = this->x;
      *y = this->y;
      *z = this->z;
    }
};

template <typename T>
bool operator<(const Point<T> _Left, const Point<T> _Right)
{
  // This is kinda arbitrary, but it's necessary to be used in a container.
  if ( abs(_Left.x - _Right.x) < MIN_DOUBLE_DIFF )
  {
    if ( abs(_Left.y - _Right.y) < MIN_DOUBLE_DIFF )
    {
      if (_Left.z < _Right.z) return true;
    } // y's are equal too
    if (_Left.y < _Right.y) return true;
  } // x's are equal
  if (_Left.x < _Right.x) return true;
  return false;
}

#endif
