#ifndef PLOT_H
#define PLOT_H

#include <iostream>
#include <iomanip>
#include <vector>
#include "GL/glut.h"
#include "point.h"

using namespace std;

#ifndef PI
#define PI 3.14159265358979323846264338327950288
#endif

class Plot
{
public:
  typedef Point<double>          point_t;
  typedef vector<double>         point_data_t;
  typedef Vector<double>         direction_t;
  typedef unsigned int           mode_t;
  typedef unsigned int           param_t;
  typedef unsigned int           coord_t;
  typedef bool                   flag_t;

  typedef void (*func_v4p)(const double &in_t, const double &in_s, const double &in_v, const int &in_time, double &out_x, double &out_y, double &out_z);
  typedef void (*func_v3p)(const double &in_t, const double &in_s, const double &in_v,                     double &out_x, double &out_y, double &out_z);
  typedef void (*func_v2p)(const double &in_t, const double &in_s,                                    double &out_x, double &out_y, double &out_z);
  typedef void (*func_v1p)(const double &in_t,                                                   double &out_x, double &out_y, double &out_z);

  typedef double (*func_3p)(const double in_t, const double in_s, const double in_v);
  typedef double (*func_2t)(const double in_t, const double in_s, const int time);
  typedef double (*func_2p)(const double in_t, const double in_s);
  typedef double (*func_1p)(const double in_t);

  typedef double (*func_car1)(const double in_x); // graph Y in terms of X
  typedef double (*func_car2)(const double in_x, const int in_time); // graph Y interms of X and doubleIME
  typedef double (*func_cyl2)(const double in_h, const double in_theta); // graph R in terms of H and doubleHEdoubleA
  typedef double (*func_cyl3)(const double in_h, const double in_theta, const int in_time); // graph R in terms of H, doubleHEdoubleA, and doubleIME
  typedef double (*func_sph2)(const double in_theta, const double in_phi); // graph R in terms of doubleHEdoubleA and PHI
  typedef double (*func_sph3)(const double in_theta, const double in_phi, const int in_time); // graph R in terms of doubleHEdoubleA, PHI, and doubleIME

  static const mode_t DISP_SOLID = 0; // Solid coloring.  It's black.
  static const mode_t DISP_COLOR = 1; // Colored from min to max.
  static const mode_t DISP_SHADE = 2; // Shaded based on surface normals.
  static const mode_t DISP_COLSH = 3; // Not supported yet; Both colored and shaded based on normals.
  static const mode_t DISP_MODES = 3; // Number of allowed disp modes

  static const mode_t SURF_POINT = 0; // Show only the points
  static const mode_t SURF_LINES = 1; // Show the lines
  static const mode_t SURF_SURFS = 2; // Show the surfaces between points/lines
  static const mode_t SURF_MODES = 3; // Number of allowed surface modes

  static const param_t PARAM_1 = 0; // X parameter
  static const param_t PARAM_2 = 1; // Y parameter
  static const param_t PARAM_3 = 2; // Z parameter
  static const param_t PARAM_T = 3; // TIME parameter

  static const coord_t COORD_CARTESIAN   = 0; // Graph in cartesian   (T1 -> X,         T2 -> Y,             T3 -> Z)
  static const coord_t COORD_CYLINDRICAL = 1; // Graph in cylindrical (T1 -> Z,         T2 -> THETA[-PI,PI], T3 -> [])
  static const coord_t COORD_SPHERICAL   = 2; // Graph in spherical   (T1 -> PHI[0,PI], T2 -> THETA[-PI,PI], T3 -> [])

  static const int POINT_X = 0;
  static const int POINT_Y = 1;
  static const int POINT_Z = 2;

  static const unsigned int COLORMAP_SIZE = 4096;

  double x_min, x_inc, x_max, y_min, y_inc, y_max, z_min, z_inc, z_max; // will be private later
private:
  mode_t m_display_mode; // see DISP_*
  mode_t m_surface_mode; // see SURF_*
  mode_t m_coord_system;
  flag_t m_autocalc;
  double m_xscale, m_yscale, m_zscale, m_tscale;
  double *****points;
  double *****normvs;
  unsigned int ****colors;
  double colormap[COLORMAP_SIZE][3];
  int xsize, ysize, zsize, tsize;
  int cur_t;

  flag_t m_normals_calculated;
  flag_t m_colors_calculated;
  flag_t m_minmax_calculated;

  // Constructor helper functions
  void init(int xsteps, int ysteps, int zsteps, int tsteps);
  void allocate();
  void deallocate();
  void assign_from(const Plot &other);

  // Plot helper functions
  void draw_color(const int &i, const int &j, const int &k, const int &n);
  void draw_vertex(const int &i, const int &j, const int &k, const int &n);

  // Calculation helper functions
  void calc_colormap_at(unsigned int p);

public:
  // Constructors
  Plot(const Plot &other);
  Plot();

  // Setup : CALL THESE BEFORE YOU PLOT! If they erase your plot, don't blame me.
  void resolution(int xres = 1, int yres = 1, int zres = 1);
  void system(coord_t graph_system = COORD_CARTESIAN); // Set what coordinate system you're using and bounds
  void bounds(param_t param, double minimum, double maximum, int steps = 100); // Customize the bounds
  mode_t surface_mode(mode_t new_mode); // Set the draw style
  mode_t display_mode(mode_t new_mode); // Set the draw style
  flag_t auto_calculate(flag_t setting); // Turn on or off auto-calculation

  // Data
  double *point(const int &x = 0, const int &y = 0, const int &z = 0, const int &time = 0);
  /* One possibility
  void parametric(func_1p);
  void parametric(func_2p);
  void parametric(func_3p);
  void parametric(func_4p); // with time
  void cartesian(func_car1);
  void cartesian(finc_car2); // with time
  void cylindrical(func_cyl2);
  void cylindrical(func_cyl3); // with time
  void spherical(func_sph2);
  void spherical(func_sph3); // with time
  */

  // dump to filename
  void dump(const char *filename);

  // External plot mechanism.
  void plot(func_1p); // could also be func_car1
  void plot(func_2p); // could also be func_car2, func_cyl2, and func_sph2
  void plot(func_2t);

  // Drawing (Must be within valid, initialized OpenGL context [see Graph])
  void predraw();
  void draw();
  void step_time(); // step the time (does NOT redraw), does bounds checking and automatically wraps.

  // Accessors
  double &xscale(); // Affect output scaling
  double &yscale(); //   ''     ''      ''
  double &zscale(); //   ''     ''      ''
  mode_t surface_mode();
  mode_t display_mode();
  flag_t auto_calculate();

  // Calculation functions
  unsigned int calc_color(const double &x, const double &y, const double &z);
  void calc_minmax();
  void calc_colors();
  void calc_normals();

  void reverse_normals();

  // Operators
  Plot &operator=(const Plot &other);

  // Destructors
  ~Plot();
  
};

#endif
