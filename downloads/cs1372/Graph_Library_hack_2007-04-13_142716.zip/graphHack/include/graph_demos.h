#ifndef GRAPH_DEMOS_H
#define GRAPH_DEMOS_H

#ifndef PI
#define PI 3.14159265358979323846264338327950288
#endif

// Cartesian
double demo_peaks(double x, double y);

// Spherical
double demo_dualsin(double phi, double theta);

// Parametric
void demo_peaks(const double &x, const double &y, const double &z, double &fx, double &fy, double &fz);
void demo_sphere(const double &x, const double &y, const double &z, double &fx, double &fy, double &fz);
double demo_sphere(const double t1, const double t2);
void demo_revolve(const double &x, const double &theta, const double &ignored, double &fx, double &fy, double &fz);
double revolve(const double x, const double theta);
void demo_sinewave(const double &x, const double &ig1, const double &ig2, const int &time, double &fx, double &fy, double &fz);
double demo_blob(const double t1, const double t2, const int time);
void demo_blob(const double &t1, const double &t2, const double &z, const int &time, double &fx, double &fy, double &fz);
void demo_conchoid(const double &u, const double &v, const double &i, const int &time, double &fx, double &fy, double &fz);
void demo_toroid(const double &t, const double &u, const double &i, const int &time, double &fx, double &fy, double &fz);
void demo_clover(const double &t, const double &u, const double &i2, const int &time, double &fx, double &fy, double &fz);

#endif
