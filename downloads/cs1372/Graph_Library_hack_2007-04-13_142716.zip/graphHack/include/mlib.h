#ifndef _MLIB_H_
#define _MLIB_H_

// This file is pretty much just an include macro.
#include "merror.h"
#include "matrix.h"
//#include "vector.h"

#endif