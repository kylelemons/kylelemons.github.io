#ifndef _sMatrix_H_
#define _sMatrix_H_

#include <stdio.h>
#include "matrix.h"

#ifdef _DEBUG
extern FILE *debug;
#endif

extern void error(char *code); 

typedef double (*d_func_d_t)(double);
typedef double (*d_func_dd_t)(double, double);
typedef double (*d_func_di_t)(double, int);
typedef double (*d_func_ddi_t)(double, double, int);
typedef double (*d_func_ddd_t)(double, double, double);


//Index a sVector
#define vindex(v, i) (v).data[i]

//sVector structure
typedef struct _vec {
	int valid;
	int length;
	double* data;
} sVector;

// Indexes by column, row...or x, y
#define mindex(m, r, c) (m).data[c + r * (m).cols]

// sMatrix structure
typedef struct _matr {
	int valid;
	int rows, cols;
	double* data;
} sMatrix;

typedef struct _di {
	double value;
	int loc;
}dblint_t;

// ------ sVector Creation/Destruction Routines ------

// Copy a sVector
sVector build(sVector from);
// Make a length l sVector
sVector build(int l, double i);
// Make a zero sVector
sVector zeros(int l);
// Make a ones sVector
sVector ones(int l);
// Colon ops
sVector colon(double from, double to);
sVector colon(double from, double inc, double to);
// Linspace
sVector linspace(double from, double to);
sVector linspace(double from, double to, double num);
// Linearize
sVector linearize(sMatrix m);
// Select elements
sVector select(sVector src, sVector ind);
// Read a sVector from a string
sVector VectorFromString(const char* c);
// Concatenation
void concat(sVector *, double);
void concat(sVector *, const sVector);
// Free a sVector
void vfree(sVector v);

// ------ sVector ops ------

// Polyfit
sVector polyfit(sVector x, sVector y, int pow);
// Polyval
double polyval(sVector coef, double x);
sVector polyval(sVector coef, sVector x);
// Summation
double sum(sVector v);
// Spline
sVector spline(sVector v);
// Scale by number
sVector operator*(sVector v, double scale);
//Add value
sVector operator+(sVector a, double d);
//Add sVector
sVector operator+(sVector a, sVector b);
//Sub value
sVector operator-(sVector a, double d);
//Sub sVector
sVector operator-(sVector a, sVector b);
//Multiply sVectors
sVector operator*(sVector a, sVector b);
//Divide sVectors
sVector operator/(sVector a, sVector b);
//Dot product
double dot(sVector a, sVector b);
sVector dotmult(sVector, sVector);
sVector dotmult(sVector, double);
sVector dotmult(double, sVector);
sVector dotdiv(sVector, sVector);
sVector dotdiv(sVector, double);
sVector dotdiv(double, sVector);
// Function Application
sVector applyFunction( d_func_d_t f, sVector A );
sVector applyFunction( d_func_dd_t f, sVector A, sVector B );
sVector applyFunction( d_func_dd_t f, sVector A, double b );
// Print
void print(FILE* f, char* s, sVector v);


// ------ sMatrix Creation/Destruction Routines ------

 // Copy a sMatrix 
sMatrix build(sMatrix from);
 // Make a r/c sMatrix filled with i
sMatrix build(int r, int c, double i);
 // Make an r/c zeros sMatrix
sMatrix zeros(int r, int c);
 // Make an r/c ones sMatrix
sMatrix ones(int r, int c);
 // Make an identity sMatrix
sMatrix identity(int s);
/* Index out src elements based on rows/cols and
     create a new sMatrix.  For example if src = [1 2 3]
												[4 5 6],
	rows = [1], cols = [1 2], then output will be [5 6]. */
sMatrix select(sMatrix src, sVector rows, sVector cols);
// Read a sMatrix from a string
// sMatrix sMatrixFromString(char* c);
sMatrix MatrixFromVector(const sVector v);
void concat( sMatrix *mp, const sMatrix m);
void vconcat( sMatrix *mp, const sMatrix m);
void vconcat( sMatrix *mp, const sVector v);
sMatrix reshape(sVector, int, int);
// Free up a sMatrix
void mfree(sMatrix m);

// ------ sMatrix ops ------

// Transpose
sMatrix transpose(sMatrix m);
// Invert
sMatrix invert(sMatrix m);
// Scale
sMatrix scale(sMatrix m, double i);
// dotmult/div
sMatrix dotmult(sMatrix a, sMatrix b);
sMatrix dotdiv(sMatrix a, sMatrix b);

// Arithmetic
sMatrix operator+(sMatrix a, sMatrix b);
sMatrix operator-(sMatrix a, sMatrix b);
sMatrix operator*(sMatrix a, sMatrix b);
sMatrix operator+(double a, sMatrix b);
sMatrix operator-(double a, sMatrix b);
sMatrix operator*(double a, sMatrix b);
sMatrix operator+(sMatrix b, double a);
sMatrix operator-(sMatrix b, double a);
sMatrix operator*(sMatrix b, double a);

// Function Application
sMatrix applyFunction( d_func_d_t f, sMatrix A );
sMatrix applyFunction( d_func_dd_t f, sMatrix A, sMatrix B );
sMatrix applyFunction( d_func_dd_t f, sMatrix A, double b );
sMatrix inv (const sMatrix given);
sVector sum(sMatrix mx);

// Print
void print(FILE* f, char* s, sMatrix m);


#endif