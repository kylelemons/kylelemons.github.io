//  DO NOT ***EVER*** RUN *CLEAN* ON THIS
// SOLUTION... YOU ****WILL**** BREAK IT!!

//   The auto-grader should set this when compiling.
// To make sure yours works, uncomment the following
// line and Build > Rebuild Solution
//#define _NO_GRAPHING

#include "graph.h"
#include "cgraph.h"
#include "leakcheck.h"
#include "graph_demos.h"

using namespace std;

#ifndef GRAPH_LIB

#define DEMO_SHOWOFF 0

// If we're using the real matrix library
// (not my cheating library)
#ifdef _sMatrix_H_
#define DEBUG_FILE
FILE *debug;
#endif

void meshgrid(sMatrix *xx, sMatrix *yy, sVector x, sVector y)
{
  sMatrix mXX, mYY;
  mXX = build(y.length, x.length, 0.0);
  mYY = build(y.length, x.length, 0.0);
  for (int r = 0; r < y.length; ++r)
  {
    for (int c = 0; c < x.length; ++c)
    {
      mindex(mXX, r, c) = vindex(x, c);
      mindex(mYY, r, c) = vindex(y, r);
    }
  }
  if (xx) *xx = mXX;
  if (yy) *yy = mYY;
}

int main(int argc, char**argv)
{
#ifdef DEBUG_FILE
  debug = fopen("debug.log", "w");
#endif
  leakcheck();
  PLOT_START(argc, argv);

  // Your code here.

#ifdef DEBUG_FILE
  fflush(debug);
  fclose(debug);
#endif

  PLOT_RUN();

  return 0;
}

#endif
