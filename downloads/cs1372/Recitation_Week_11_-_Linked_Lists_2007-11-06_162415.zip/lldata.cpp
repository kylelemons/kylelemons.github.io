#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "lldata.h"

LLData *newData()
{
  LLData *ret = (LLData*)calloc(1,sizeof(LLData));
  return ret;
}

LLData *copyData(const LLData *old)
{
  LLData *copy = newData();
  *copy = *old;
  return copy;
}

void freeData(LLData *d)
{
  free(d);
}

bool less(const LLData *a, const LLData *b)
{
  return (strcmp(a->name, b->name) < 0);
}

// Printing
void print(const LLData *d)
{
  printf("%20s %4d %4d %4d ...\n", d->name, d->grades[0], d->grades[1], d->grades[2], d->grades[3]);
}