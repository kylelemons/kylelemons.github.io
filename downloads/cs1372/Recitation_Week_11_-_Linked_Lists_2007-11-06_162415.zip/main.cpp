#include <stdio.h>
#include <string.h>

#include "lldata.h"
#include "llist.h"

int main(int nargin, char **arg)
{
  LList *list = createList();

  char buf[256], *ret;
  do
  {
    fputs("Enter a name (^Z to finish): ", stdout);
    ret = fgets(buf, 256, stdin);
    if (ret)
    {
      LLNode *student = createNode();
      strcpy(student->data->name, buf);
      /* enter grades */
      list = addSorted(list, student);
    }
  } while (ret);

  strcpy(buf, "Student Gradebook:");
  fputs(buf, stdout);

  /* Loop through the students */
  LList *head = list;
  while (head)
  {
    fputs("  ", stdout);
    print(head->data);
    /* For an infinite loop:
      if (hasNext(head))
        head = getNext(head);
      else
        break;
    */
    head = getNext(head);
  }

  return 0;
}