#ifndef LLIST_H
#define LLIST_H

#include "lldata.h"

typedef struct _llnode {
  LLData *data;
  struct _llnode *next;
} LLNode;

typedef LLNode LList;

/* List operations */
LList *createList();
LList *addToHead(LList *head, LLNode *node);
LList *addToTail(LList *head, LLNode *node);
LList *addSorted(LList *head, LLNode *node);
LList *removeFromHead(LList *head);
LList *destroyList(LList *head);
LList *copyList(LList *head);

/* List iteration */
bool hasNext(LList *head);
LList *getNext(LList *head);

/* Node operations */
LLNode *createNode();
LLNode *destroyNode(LLNode *node);
LLNode *copyNode(LLNode *old);

#endif /* LLIST_H */