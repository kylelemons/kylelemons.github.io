#include <stdio.h>

// IO Parameters
void separate(  double dInput,
                int    *piWholePart,
                double *pdFracPart,
                bool   *pbPositive
                )
{
  if (dInput < 0.0)
  {
    *pbPositive = false;
  }
  else
  {
    *pbPositive = true;
  }

  *piWholePart = (int)dInput;
  *pdFracPart = dInput - *piWholePart;
}

// Scope

void scopeDemo()
{
  int iAge = 45;
  for (int iYearsAtTech = 0; iYearsAtTech < 40; iYearsAtTech++)
  {
    //int iAge = 0;
    printf("Prof. Smith has been at tech for %d years when he was %d\n", iYearsAtTech, iAge + iYearsAtTech);
  }
  printf("Smith is: %d\n", iAge);
}