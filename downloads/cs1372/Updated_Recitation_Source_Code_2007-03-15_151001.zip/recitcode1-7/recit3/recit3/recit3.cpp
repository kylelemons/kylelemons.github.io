#include <stdio.h>
#include <math.h>

#include "functions.h"

int main(int argc, char **argv)
{
#if 0

  // Input parameters
  double dValue = 31.3333;

  // Output parameters
  int iWhole;
  double dFrac;
  bool bPositive;

  int* piWhole = &iWhole; // same as using &iWhole below
  separate( dValue, piWhole, &dFrac, &bPositive );

  printf("Whole part of %f: %d\n", dValue, iWhole);
  printf("Fractional part of %f: %f\n", dValue, dFrac);
  printf("Is %f positive? %d\n", dValue, (int)bPositive);

#endif 

  scopeDemo();
  return 0;
}