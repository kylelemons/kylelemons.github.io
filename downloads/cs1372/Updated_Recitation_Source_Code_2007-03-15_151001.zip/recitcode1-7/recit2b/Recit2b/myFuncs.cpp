#include <stdio.h>
#include "myFuncs.h"

void swap( int* piA, int* piB )
{
  int iTemp = *piA;
  *piA = *piB;
  *piB = iTemp;
} // swap the values in iA and iB

void swap2( int iA, int iB )
{
  int iTemp = iA;
  iA = iB;
  iB = iTemp;
  printf("Answer: %d\n", iA);
  printf("Question: %d\n", iB);
} // swap the values in iA and iB

// Mini Quiz Part B
void count()
{
  /*
  for(int i=100; i>=1; i--){
    printf("%d\n", i);
  }
*/
  int iNum = 1;
  while(iNum <= 100) {
    printf("%d\n",iNum);
    iNum++;
  }//while
} // count from 1 to 100 (inclusive)