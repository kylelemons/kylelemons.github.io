#pragma once

void rotate( int *, int *, int *);