typedef struct {
  char *encrypted;
  char *decrypted;
  unsigned int beg;
  unsigned int len;
} SMessage;

typedef struct {
  unsigned long key[256];
  SMessage *message;
} SCrackStats;

void gen();
void analyze(SCrackStats *w);