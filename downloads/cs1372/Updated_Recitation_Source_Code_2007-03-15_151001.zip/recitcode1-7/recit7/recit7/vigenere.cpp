void encrypt(const char *src, const char *key, char *dest)
{
  const char *k = key;
  while (*src)
  {
    int iChar = *src + *k;
    while (iChar > 126)
    {
      int diff = iChar - 126;
      iChar = 32 + diff;
    }
    if (*src == ' ')
      iChar = (int)' ';
    *dest = (char)iChar;
    src++;
    dest++;
    k++;
    if (*k == '\0')
      k = key;
  }
}

void decrypt(const char *src, const char *key, char *dest)
{
  const char *k = key;
  while (*src)
  {
    int iChar = *src - *k;
    while (iChar <= 32)
    {
      int diff = 32 - iChar;
      iChar = 126 - diff;
    }
    if (*src == ' ')
      iChar = (int)' ';
    *dest = (char)iChar;
    src++;
    dest++;
    k++;
    if (*k == '\0')
      k = key;
  }
 // printf("Decrypted: %s\n", m->decrypted);
}