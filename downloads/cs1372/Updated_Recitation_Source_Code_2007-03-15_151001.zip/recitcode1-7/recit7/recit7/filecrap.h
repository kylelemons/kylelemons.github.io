#include <stdio.h>
#include <stdlib.h>

#pragma once

char *readFile(FILE *fIn);
char *my_strncpy(char *dest, const char *src, int copy_max);
char *my_strchr(const char *s, int c);
void split(char* tosplit, char* delim, char*** parsed, int* len);
void freesplit(char ***parsed, int strings);