#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "lldata.h"
#include "llist.h"

char *trim(const char *input);

int main(int nargin, char **arg)
{
  LList *list = createList();

  char buf[256], *ret, *gret;
  do
  {
    fputs("Enter a name (^Z to finish): ", stdout);
    ret = fgets(buf, 256, stdin);
    if (ret)
    {
      LLNode *student = createNode();
      char *trimmed = trim(buf);
      strcpy(student->data->name, trimmed);
      free(trimmed);
      /* enter grades */
      int grade = 0;
      int gradecnt = 0;
      do
      {
        fprintf(stdout, "  Grade %d (^Z to finish): ", gradecnt+1);
        gret = fgets(buf, 256, stdin);
        if (gret)
          student->data->grades[gradecnt] = atoi(buf);
        else
          break;
        gradecnt++;
      } while (gret && gradecnt < 64);
      list = addSorted(list, student);
    }
  } while (ret);

  strcpy(buf, "Student Gradebook:\n");
  fputs(buf, stdout);

  /* Loop through the students */
  LList *head = list;
  //head = getNext(head); // To get the next one as the first one s garbage
  while (head)
  {
    fputs("  ", stdout);
    print(head->data);
    /* For an infinite loop:
      if (hasNext(head))
        head = getNext(head);
      else
        break;
    */
    head = getNext(head);
  }

  return 0;
}

char *trim(const char *input)
{
  const char *b, *e;
  char *o;
  b = input;
  e = input + strlen(input);
  while (isspace(*b))     ++b;
  while (isspace(*(e-1))) --e;
  o = (char*)calloc(e-b+1, sizeof(char));
  memcpy(o, b, e-b);
  return o;
}