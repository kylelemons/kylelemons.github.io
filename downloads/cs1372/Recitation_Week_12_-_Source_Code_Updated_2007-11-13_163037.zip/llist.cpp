#include <stdlib.h>
#include <stdio.h>
#include "llist.h"


/* List operations */
LList *createList()
{
  LList *head = NULL; //createNode(); //(LList*)calloc(1,sizeof(LList));
  return head;
}

LList *addToHead(LList *head, LLNode *node)
{
  node->next = head;
  return node;
}

LList *addToTail(LList *head, LLNode *node)
{
  if (head == NULL)
    return node;
  head->next = addToTail(head->next, node);
  return head;
}

LList *addSorted(LList *head, LLNode *node)
{
  if (head == NULL)
    return node;
  if (less(node->data, head->data))
  {
    node->next = head;
    return node;
  }
  head->next = addSorted(head->next, node);
  return head;
}

LList *removeFromHead(LList *head)
{
  LList *newhead = head->next;
  destroyNode(head);
  return newhead;
}

LList *destroyList(LList *head)
{
  if (head == NULL)
    return NULL;
  LLNode *next = head->next;
  destroyNode(head);
  return destroyList(next);
}

LList *copyList(LList *head)
{
  if (head == NULL)
    return NULL;
  LList *copy = copyNode(head);
  copy->next = copyList(head->next);
  return NULL;
}

/* List iteration */
bool hasNext(LList *head)
{
  return (head->next != NULL);
}

LList *getNext(LList *head)
{
  return head->next;
}

/* Node operations */
LLNode *createNode()
{
  LLNode *n = (LLNode*)calloc(1,sizeof(LLNode));
  n->data = newData();
  return n;
}

LLNode *destroyNode(LLNode *node)
{
  freeData(node->data);
  free(node);
  return NULL;
}

LLNode *copyNode(LLNode *old)
{
  LLNode *copy = createNode();
  *copy = *old;
  copy->data = copyData(old->data);
  return NULL;
}