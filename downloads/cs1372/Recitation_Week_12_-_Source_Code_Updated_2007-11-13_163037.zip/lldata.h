#ifndef LLDATA_H
#define LLDATA_H

typedef struct _lldata {
  char name[256];
  int  grades[64];
} LLData;

LLData *newData();
LLData *copyData(const LLData *old);
void freeData(LLData *d);

// Comparison
bool less(const LLData *a, const LLData *b);

// Printing
void print(const LLData *d);

#endif /* LLDATA_H */