#include "miniquiz.h"

// This is the function definition, it includes a code body
int major(int i, double x, double y)
{
  /* anything that will compile */
 	//return 0; // again, it must compile
  return i/y;
}