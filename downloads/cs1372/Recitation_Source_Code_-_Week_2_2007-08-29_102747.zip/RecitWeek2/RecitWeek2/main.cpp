#include <stdio.h>
#include "miniquiz.h"
#include "week2.h"

//#define MINIQUIZ

int main(int argc, char **argv)
{
#ifdef MINIQUIZ
  // Example of how to use the MiniQuiz function
  int input1 = 42;      // integer value for input into major()
  float input2 = 19.6;  // floating point value for input into major()
  float input3 = .0001; // floating point value for input into major()
  int value = major(input1, input2, input3);
  printf("major(%d,%f,%f) = %d\n", input1, input2, input3, value);
#else
  //codeblocks();
  //conditionals();
  switching();
#endif
  return 0;
}