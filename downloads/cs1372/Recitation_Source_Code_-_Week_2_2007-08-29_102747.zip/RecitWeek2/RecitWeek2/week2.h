#ifndef WEEK2_H
#define WEEK2_H

// Demonstrate code blocks
void codeblocks();

// Demonstrate the use of conditionals
void conditionals();

// Demonstrate switching constructs
void switching();

#endif /* WEEK2_H */