#ifndef MINIQUIZ_H
#define MINIQUIZ_H

// This is the function definition, it tells the compiler about the arguments
int major(int, double, double);

#endif /* MINIQUIZ_H */