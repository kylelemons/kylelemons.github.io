#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "week2.h"

// Demonstrate code blocks
void codeblocks()
{
  int a = 1;
  printf("1. a = %d\n", a);
  
  {
    int a = 2;
    printf("2. a = %d\n", a);
  }

  printf("3. a = %d\n", a);

  {
    a = 3;
    printf("4. a = %d\n", a);
  }

  printf("5. a = %d\n", a);
}

// Demonstrate the use of conditionals
void conditionals()
{
  int grade;
  printf("What grade did you get? ");
  scanf("%d", &grade);

  if (grade >= 80)
  {
    printf("Well done!\n");
  }
  else if (grade >= 70)
  {
    printf("You can do better than that...\n");
  }
  else if (grade >= 60)
  {
    printf("You passed... barely\n");
  }
  else
  {
    printf("Ooops! %d is a failing grade.\n", grade);
  }
}

// Demonstrate switching constructs
void switching()
{
  char string[256];
  printf("Type some letters: ");
  fgets(string, 256, stdin);

  char *p = string;
  while (*p)
  {
    if (!isspace(*p))
    {
      printf("The letter %c is a(n): ", *p);
      switch (*p)
      {
        case 'A':
        case 'E':
        case 'I':
        case 'O':
        case 'U':
          printf("Uppercase ");
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
          printf("Vowel\n");
          break;
        case 'Y':
          printf("Uppercase ");
        case 'y':
          printf("Sometimes Vowel\n");
          break;
        default:
          if (isalpha(*p))
          {
            printf("Consonant\n");
          }
          else
          {
            printf("Symbol\n");
          }
          break;
      }
    }
    ++p;
  }
}