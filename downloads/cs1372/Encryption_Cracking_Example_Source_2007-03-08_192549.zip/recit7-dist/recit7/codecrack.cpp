#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codecrack.h"
#include "vigenere.h"

void gen()
{
  const char *s1 = "This is not a test.";
  const char *s2 = "This code is uncrackable!";
  const char *s3 = "Meet on top of Klaus at midnight. Or Else.";
  const char *s4 = "Elvis has left the building.";
  const char *s5 = "Something wicked this way comes!";
  const char *s6 = "L33t sp34k pr0b4bly w0n't d3cryp7.";
  const char *s7 = "ReTURn immEDiaTelY to YOUr SpoNSOr";

  const char *k1 = "C";//"(@#$*)@!!KAss";
  const char *k2 = "k39JJSC((@@1@1*";
  const char *k3 = "%";//"*#&$@@";
  const char *k4 = "#";
  const char *k5 = "A";
  const char *k6 = ")";
  const char *k7 = "~";

  char *e1 = (char *)calloc(strlen(s1)+1, sizeof(char));
  char *e2 = (char *)calloc(strlen(s2)+1, sizeof(char));
  char *e3 = (char *)calloc(strlen(s3)+1, sizeof(char));
  char *e4 = (char *)calloc(strlen(s3)+1, sizeof(char));
  char *e5 = (char *)calloc(strlen(s3)+1, sizeof(char));
  char *e6 = (char *)calloc(strlen(s3)+1, sizeof(char));
  char *e7 = (char *)calloc(strlen(s3)+1, sizeof(char));

  encrypt(s1, k1, e1);
  encrypt(s2, k2, e2);
  encrypt(s3, k3, e3);
  encrypt(s4, k3, e4);
  encrypt(s5, k3, e5);
  encrypt(s6, k3, e6);
  encrypt(s7, k3, e7);

  FILE *fout;
  fout = fopen("secure.txt", "w");
  if (!ferror(fout))
  {
    fprintf(fout, "To Agent1: %s\n", e1);
    fprintf(fout, "To Agent2: %s\n", e2);
    fprintf(fout, "To Agent3: %s\n", e3);
    fprintf(fout, "To Agent4: %s\n", e4);
    fprintf(fout, "To Agent5: %s\n", e5);
    fprintf(fout, "To Agent6: %s\n", e6);
    fprintf(fout, "To Agent7: %s\n", e7);
  }
  fclose(fout);
}

void analyze(SCrackStats *stats)
{
  char key[2] = ".";
  int skip = stats->message->beg;
    
  //printf("Analyzing \"%s\"...\n", stats->message->encrypted);
  for (unsigned char k = 33; k <= 126; ++k)
  {
    char *newword = strdup(stats->message->encrypted);
    key[0] = k;
    decrypt(stats->message->encrypted + skip, key, newword + skip);
      
    //printf("Encrypted with %c: %s\n", k, newword);
    for (char *c = newword; *c; ++c)
    {
      if ('A' <= *c && *c <= 'Z')
        stats->key[k] += 2; // two points for a capital letter
      if ('a' <= *c && *c <= 'z')
        stats->key[k] += 2; // two points for a capital letter
      if (*c == '.' || *c == ',' || *c == '?' || *c == '!')
        stats->key[k] += 1; // one point for a punctuation
    }
    //printf("key['%c'] = %d (%s)\n", k, stats->key[k], newword);
    free(newword);
  }
  char best = '\0';
  for (unsigned k = 0; k < 256; ++k)
  {
    if (stats->key[k] >= stats->key[best])
    {
      best = k;
    }
  }
  key[0] = best;
  if (stats->message->decrypted)
   free(stats->message->decrypted);
  stats->message->decrypted = strdup(stats->message->encrypted);
  decrypt(stats->message->encrypted + skip,
          key,
          stats->message->decrypted + skip);
  //printf("Best:      %s\n", stats->message->decrypted);
}