#pragma once

void encrypt(const char *src, const char *key, char *dest);
void decrypt(const char *src, const char *key, char *dest);
