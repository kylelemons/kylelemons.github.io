#include <stdlib.h>
#include <stdio.h>

char *readFile(FILE *fIn)
{
  char *file = NULL;
  int len = 0;
  char c;
  while (feof(fIn)==0 && ferror(fIn)==0)
  {
    c = fgetc(fIn);
    if (c == EOF)
      break;
    file = (char*)realloc(file, len+2);
    file[len] = c;
    file[++len] = '\0';
  }
  if (ferror(fIn))
  {
    perror("fileRead");
  }
  return file;
}

char *my_strncpy(char *dest, const char *src, int copy_max)
{
  for (int i = 0; i < copy_max-1 && src[i]; ++i, ++dest)
    *dest = src[i];
  *dest = '\0';
  return dest;
}

char *my_strchr(const char *s, int c)
{
  while (*s && *s != c) ++s;
  if (*s) return (char *)s;
  return NULL;
}


void split(char* tosplit, char* delim, char*** parsed, int* len)
{
  char **list = NULL;
  int tf = 0; // Token First index
  int tl = 0; // Token Length
  int tc = 0; // Token Count
  char *c = tosplit; // current character
  char *d = NULL; // delim pointer
  char *temp = NULL; // temp string
  while (c) // infinite loop
  {
    d = my_strchr(delim, *c);
    if (d || *c == '\0')
    {
      tl = int(c - tosplit) - tf;
      temp = (char *)calloc(tl+1, sizeof(char));
      my_strncpy(temp,tosplit+tf,tl+1);
      list = (char**)realloc(list, (tc+1) * sizeof(char*));
      list[tc] = temp;
      ++tc;
      tf = int(c - tosplit) + 1;
    } // Found Delimiter

    if (*(c++) == '\0') break; // if so, exit
  }
  if (parsed != NULL) *parsed = list; // the list we made
  if (len != NULL)    *len    = tc; // the final token count
}

void freesplit(char ***parsed, int strings)
{
  // Loop over the strings
  for (int i = 0; i < strings; ++i)
  {
    // free the small arrays (the strings)
    free((*parsed)[i]);
  }
  // Free the big array
  free(*parsed);
  *parsed = NULL;
}


