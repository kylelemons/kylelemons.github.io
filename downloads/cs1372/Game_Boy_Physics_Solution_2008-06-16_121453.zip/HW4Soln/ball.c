#include <math.h>
#include <stdlib.h>

#include "ball.h"
#include "myLib.h"

///////////////////////////////////////
/* Coordinate utility math functions */
// Find the vector from a to b ////////
Coord vec(Coord a, Coord b)
{
  Coord n = {b.x - a.x, b.y - a.y};
  return n;
}
// Find the tangent of the vector /////
Coord tangent(Coord x)
{
  Coord n = {x.y, -x.x};
  return n;
}
// Find the magnitude /////////////////
float mag(Coord x)
{
  return sqrt(x.x*x.x + x.y*x.y);
}
// Find the magnitude squared /////////
float mag2(Coord x)
{
  return x.x*x.x + x.y*x.y;
}
// Find the unit vector ///////////////
Coord unit(Coord x)
{
  Coord n = { x.x/mag(x), x.y/mag(x) };
  return n;
}
// Find the dot product ///////////////
float dot(Coord a, Coord b)
{
  return a.x*b.x + a.y*b.y;
}
// Find the scaled vector /////////////
Coord mult(Coord x, float k)
{
  Coord n = { x.x*k, x.y*k };
  return n;
}
// Add the two vectors ////////////////
Coord add(Coord a, Coord b)
{
  Coord n = { a.x + b.x, a.y + b.y };
  return n;
}
/* Coordinate utility math functions */
///////////////////////////////////////

void drawBall(Ball *b)
{
  int x0 = b->pos.x;
  int y0 = b->pos.y;
  int r = b->r;
  int f = 1 - r;
  int ddF_x = 0;
  int ddF_y = -2 * r;
  int x = 0;
  int y = r;

  fillRectDMA3(y0 - r, x0, 2*r + 1, 1, b->color);
  fillRectDMA3(y0, x0 - r, 1, 2*r + 1, b->color);

  while(x < y)
  {
    if(f >= 0)
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x + 1;

    // See the wikipedia entry on integer circle drawing to see how I derived this
    fillRectDMA3(y0 + y, x0 - x, 1, 2*x+1, b->color);
    fillRectDMA3(y0 - y, x0 - x, 1, 2*x+1, b->color);
    fillRectDMA3(y0 + x, x0 - y, 1, 2*y+1, b->color);
    fillRectDMA3(y0 - x, x0 - y, 1, 2*y+1, b->color);
  }
}

void drawBalls(Ball **b, int count)
{
  int i;
  for (i = 0; i < count; drawBall(b[i++]));
}

Ball *newBall(float mass, int radius, Color color)
{
  Ball *n = (Ball *)calloc(1, sizeof(Ball));
  n->mass = mass;
  n->r = radius;
  n->color = color;
  // Remember to free any balls you get from here!!
  return n;
}

void freeBall(Ball *b)
{
  // Free the structure.
  free(b);
}

void updatePosition(Ball *b)
{
  // Standard physics position update.  No momentum, because there's no acceleration.
  b->pos.x += b->v.x;
  b->pos.y += b->v.y;
}

void updateBallPositions(Ball **b, int count)
{
  unsigned i;
  for (i = 0; i < count; ++i)
    updatePosition(b[i]);
}

float distance(Coord c1, Coord c2)
{
  // Distance formula (without pow())
  return sqrt( (c2.x-c1.x)*(c2.x-c1.x) + (c2.y-c1.y)*(c2.y-c1.y) );
}

int ballCollision(Ball *b1, Ball *b2)
{
  // if dist(x,y) < r1 + r2, the balls are colliding
  return (distance(b1->pos, b2->pos) <= b1->r + b2->r);
}

int wallCollision(Ball *b, Wall w)
{
  // Based on the wall given, check the bounds of b
  switch (w)
  {
    case WALL_TOP:
      return b->pos.y <= b->r;
    case WALL_BOTTOM:
      return b->pos.y >= SCREEN_HEIGHT - b->r;
    case WALL_LEFT:
      return b->pos.x <= b->r;
    case WALL_RIGHT:
      return b->pos.x >= SCREEN_WIDTH - b->r;
    default:
      return 0;
  }
}

int checkBallCollisions(Ball ***_b, int count)
{
  unsigned i,j,w;
  Ball **b = *_b;
  // This count keeps track of how many there are.  Count just knows how many we started with.
  int real_count = count;
  // Loop over all of the ORIGINAL balls
  for (i = 0; i < count; ++i)
  {
    // Compare them with all of the balls that haven't had collision detection performed yet
    for (j = i+1; j < count; ++j)
      // If the balls are colliding
      if (ballCollision(b[i], b[j]))
      {
        // Modify the velocities, etc
        performBallCollision(b[i], b[j]);
        // If the radii are the same
        if (b[i]->r == b[j]->r)
        {
          // Cut the radii in half (and increment by one so subsequent collisions won't multiply)
          b[i]->r /= 2; b[j]->r /= 2; b[i]->r++; b[j]->r++;
          // Create space in the array for a new ball
          b = (Ball**)realloc(b, (real_count+1)*sizeof(Ball*));
          // Create the new ball with the same radius, minus one (so that a subsequent collision won't multiply)
          b[real_count] = newBall( randFloat(1,10), b[i]->r-1, randColor() );
          // Position the new ball halfway in between.  pos = pos1+.5(pos2-pos1)
          b[real_count]->pos = add(b[i]->pos,mult(vec(b[i]->pos, b[j]->pos),0.5));
          // Move the first ball until it's not colliding with the new one
          while (ballCollision(b[i], b[real_count]))
            updateBallPositions(b+i, 1);
          // Move the second ball until it's not colliding with the new one
          while (ballCollision(b[j], b[real_count]))
            updateBallPositions(b+j, 1);
          // Update the real ball count so that any further collisions don't clobber this one
          real_count++;
        }
        // Add to the radius of the smaller ball
        else if (b[i]->r < b[j]->r)
        {
          b[i]->r += 1;
        }
        else
        {
          b[j]->r += 1;
        }
        // Update the positions of both balls until they aren't colliding any more (prevents "balloon" effect)
        while (ballCollision(b[i], b[j]))
        {
          updateBallPositions(b+i, 1);
          updateBallPositions(b+j, 1);
        }
      }
    // Check for wall collisions, and modify accordingly
    for (w = 0; w < WALL_MAX; ++w)
      if (wallCollision(b[i], w))
        performWallCollision(b[i], w);
  }
  // Save the array back to the calling function
  *_b = b;
  // Inform the calling function of the new number of balls
  return real_count;
}

void performBallCollision(Ball *b1, Ball *b2)
{
  float m1 = b1->mass;
  float m2 = b2->mass;

  // calculate the new vector (see wikipedia on 2D collisions)
  Coord un = unit(vec(b1->pos, b2->pos));
  Coord ut = unit(tangent(un));
  float v1n = dot(un,b1->v);
  float v1t = dot(ut,b1->v);
  float v2n = dot(un,b2->v);
  float v2t = dot(ut,b2->v);
  float v1np = (v1n*(m1-m2) + 2*m2*v2n) / (m1+m2);
  float v2np = (v2n*(m2-m1) + 2*m1*v1n) / (m1+m2);
  
  b1->v = add( mult(un, v1np), mult(ut, v1t) );
  b2->v = add( mult(un, v2np), mult(ut, v2t) );
}

void performWallCollision(Ball *b, Wall w)
{
  // Call reflect() with the proper arguments for the wall given
  switch (w)
  {
    case WALL_TOP:
      reflect(&b->pos.y, &b->v.y, b->r);
      break;
    case WALL_BOTTOM:
      reflect(&b->pos.y, &b->v.y, SCREEN_HEIGHT - b->r);
      break;
    case WALL_LEFT:
      reflect(&b->pos.x, &b->v.x, b->r);
      break;
    case WALL_RIGHT:
      reflect(&b->pos.x, &b->v.x, SCREEN_WIDTH - b->r);
      break;
    default:
      break;
  }
}

void reflect(float *pos, float *velocity, float barrier)
{
  // Determine how far through the "barrier" it went
  float part = (*pos - barrier) / *velocity;
  // Take this amount off of the velocity
  *pos -= *velocity * part;
  // reflect the velocity
  *velocity *= -1;
  // add that amount back in the correct direction
  *pos += *velocity * part;
}

/* Returns a random integer between lower and upper */
int randInt(int lower, int upper)
{
    return (int) floor((((double) rand()/ (double) RAND_MAX) * (upper-lower)) + lower + 0.5);
}
/* Returns a random double between lower and upper */
double randDouble(int lower, int upper)
{
    return (((double) rand()/ (double) RAND_MAX) * (upper-lower)) + lower;
}
/* Returns a random float between lower and upper */
float randFloat(int lower, int upper)
{
    return (((float) rand()/ (float) RAND_MAX) * (upper-lower)) + lower;
}
/* Returns a random color */
Color randColor()
{
    return RGB(randInt(0,31), randInt(0,31), randInt(0,31));
}
Color averageColors(Color c1, Color c2)
{
    Color red = ((c1 & 0x1F) + (c2 & 0x1F))>>1;
    Color green = (((c1>>5) & 0x1F) + ((c2>>5) & 0x1F))>>1;
    Color blue = (((c1>>10) & 0x1F) + ((c2>>10) & 0x1F))>>1;
    return RGB(red,green,blue);
}
