#include "myLib.h"

/* declarations */
         u16 *videoBuffer     = (u16 *)0x6000000;
         u16 *FrontBuffer     = (u16 *)0x6000000;
         u16 *BackBuffer      = (u16 *)0x600A000;
volatile u16 *scanlineCounter = (u16 *)0x4000006;
volatile u32 *BUTTONS         = (volatile unsigned int *)0x04000130;
volatile u16 *palette_mem     = (volatile u16 *)0x5000000;

/* screen base block (For tile maps)*/
 screenblock *screenbase      = (screenblock *)0x6000000;
/* char base block (For tile images)*/
   charblock *charbase   =   (charblock *)0x6000000;


void setPixel3(u16 row, u16 col, u16 color)
{
    videoBuffer[OFFSET3(row, col)] = color;
}

void fillRect3(u16 row, u16 col, u16 height, u16 width, u16 color)
{
    int r;
    int c;
    for(r = row; r < row+height; r++)
    {
        for(c=col; c < col+width; c++)
        {
            videoBuffer[OFFSET3(r,c)] = color;
        }
    }
}

void fillScreen3(u16 color)
{
    u16 *tp;
    for(tp=videoBuffer; tp<videoBuffer+(160*240); tp++)
    {
        *tp = color;
    }
}

/* NOTE: The address given as the source must be volatile!*/
void fillScreenDMA3(volatile u16 color)
{
    u32 mode = DMA_SRC_FIXED | DMA_16 | DMA_ON;
    DMA_TRANSFER(videoBuffer, &color, 160*240, 3, mode);
}

void fillScreenDMA4(volatile u8 color)
{
    volatile u32 buffer = (color << 24) | (color << 16) | (color << 8) | color;
    u32 mode = DMA_SRC_FIXED | DMA_32 | DMA_ON;
    DMA_TRANSFER(videoBuffer, &buffer, 160*240/4, 3, mode);
}



void fillRectDMA3(u16 row, u16 col, u16 height, u16 width, u16 color)
{
    u16 *start;
    int i;
    for(i=row; i<row+height; i++)
    {
        start = videoBuffer + (i*240+col);
        DMA_TRANSFER(start, &color, width, 3, DMA_SRC_FIXED | DMA_16 | DMA_ON);
    }
}

void fillRectDMA4(u16 row, u16 col, u16 height, u16 width, u8 color)
{
    int r;
    u16 pixel;
    u16 offset;
    volatile u16 kolor = color<<8 | color;
    int w;
    for(r=row; r<row+height; r++)
    {
        if(col & 1) /* Is column odd?*/
        {
            setPixel4(r, col, color);
            pixel = r * 240 + col + 1;
            w = width - 1;
        }
        else
        {
            pixel = r * 240 + col;
            w = width;
        }
        offset = pixel >> 1;
        DMA_TRANSFER(&videoBuffer[offset], &kolor, w/2, 3, DMA_SRC_FIXED | DMA_16 | DMA_ON);
        if((col + width) & 1)
        {
            setPixel4(r, col+width-1, color);
        }
    }
            

		
        
} /* void fillRectDMA4*/
    


void waitForVblank()
{
    while(*scanlineCounter != 160);
    /*while(*scanlineCounter >= 160);*/
    /*while(*scanlineCounter < 160);*/
}

void FlipPage(void)	
{
    if(REG_DISPCNT & BACKBUFFER)
    {
        /* Was displaying BackBuffer*/
        REG_DISPCNT &= ~BACKBUFFER;
        videoBuffer = BackBuffer;
    }
    else
    {
        /* Was displaying FrontBuffer*/
        REG_DISPCNT |= BACKBUFFER;
        videoBuffer = FrontBuffer;
    }
} /* FlipPage*/

void setPixel4(u16 row, u16 col, u8 color)
{
		/* Determine which pixel we are changing*/
		u16 pixel = row * 240 + col;
		/* Determine which short controls that pixel (/2)*/
		u16 offset = pixel >> 1;
		/* Get that short*/
		u16 ts = videoBuffer[offset];
		if(col & 1)
		{
			/* odd column: Mask upper bits and put color there*/
			videoBuffer[offset] = (color << 8) | (ts & 0x00FF);
		}
		else
		{
			/* even column: Mask lower bits and put color there*/
			videoBuffer[offset] = (ts & 0xFF00) | color;
		}
} /* setPixel4*/

int isEven(int x)
{
    if(x & 1)
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

        



