#include <stdlib.h>
#include <math.h>

#include "myLib.h"
#include "ball.h"

#define SIGN(x) (x<0?-1:1)

int main(void)
{
  int i;
  float dt = 1/3.; //1/5.; //1/60.; // Steps to calculate between screen draws.
  int count;
  Ball **bArr;
  
  // Keep running until the user hits START and SELECT to exit
  while(!KEY_DOWN(KEYSTART) || !KEY_DOWN(KEYSELECT))
  {
    count = 3;
    // Allocate the initial array
    bArr = (Ball**)calloc(count, sizeof(Ball*));
    for (i = 0; i < count; ++i)
    {
      // Create a new ball for each with a random mass and radius and color
      bArr[i] = newBall( randFloat(1,10), randInt(8,18), randColor() );
      // Give it a random velocity
      bArr[i]->v.x = randFloat(-5,5)*dt;
      bArr[i]->v.y = randFloat(-5,5)*dt;
      // Give it a random position
      bArr[i]->pos.x = randInt(10,SCREEN_WIDTH-10);
      bArr[i]->pos.y = randInt(10,SCREEN_HEIGHT-10);
    }
    // Draw the balls to the screen
    fillScreenDMA3(BLACK);
    drawBalls(bArr, count);

    REG_DISPCNT = BG2_ENABLE | MODE3;

    // Wait to move them until the user presses START
    while(!KEY_DOWN(KEYSTART));
    // Keep running until the user hits SELECT to reset
    while(!KEY_DOWN(KEYSELECT))
    {
      float t;
      // To be accurate but still fast, perform a few smaller increments (hence dt above)
      for (t = 0; t < 1; t += dt)
      {
        updateBallPositions(bArr, count);
        count = checkBallCollisions(&bArr, count);
      }
      // ... before drawing the balls on the screen
      waitForVblank();
      fillScreenDMA3(BLACK);
      drawBalls(bArr, count);
    }

    // Free all of the memory we used.
    for (i = 0; i < count; ++i)
      free(bArr[i]);
    free(bArr);
  }
  // Exit the game.  VBA will reset the game and start over, this probably won't happen in hardware.
  return 0;
}

/* END OF FILE */
