#ifndef BALL_H
#define BALL_H

#include "myLib.h"

typedef u16 Color;
typedef struct _coord {
  float x, y;
} Coord;
typedef struct _ball {
  Coord v, pos;
  float mass;
  int r;
  Color color;
} Ball;
typedef enum {
  WALL_TOP = 0,
  WALL_LEFT,
  WALL_RIGHT,
  WALL_BOTTOM,
  WALL_MAX
} Wall;

void reflect(float *pos, float *velocity, float barrier);
void drawBall(Ball *b);
void drawBalls(Ball **b, int count);
Ball *newBall(float mass, int radius, Color color);
void freeBall(Ball *b);
void updatePosition(Ball *b);
void updateBallPositions(Ball **b, int count);
float distance(Coord c1, Coord c2);
int ballCollision(Ball *b1, Ball *b2);
int wallCollision(Ball *b, Wall w);
int checkBallCollisions(Ball ***b, int count);
void performBallCollision(Ball *b1, Ball *b2);
void performWallCollision(Ball *b, Wall w);

int randInt(int lower, int upper);
double randDouble(int lower, int upper);
float randFloat(int lower, int upper);
Color randColor();
Color averageColors(Color c1, Color c2);

#endif
