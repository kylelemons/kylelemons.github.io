#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <limits.h>
//
//void mystery_array_func(int* arr, int length, int num) {
//int curr_index = 0, temp, prev_val;
//// No point if the array is length 0
//if (length == 0) {
//return;
//}
//// Correct for numbers not in the range [0, length - 1]
//num %= length;
//if (num < 0)
//num += length;
//// Do our shifts, stop when we've gone over the entire array
//prev_val = arr[curr_index];
//do {
//int replace_index = (curr_index + num) % length;
//temp = arr[replace_index];
//arr[replace_index] = prev_val;
//prev_val = temp;
//curr_index = replace_index;
//} while (curr_index != 0);
//}
//void print_array(int* array, int length) {
//printf("[");
//for (int i = 0; i < length; ++i) {
//printf("%i ", array[i]);
//}
//printf("]\n");
//}
//int main() {
//int array[] = {0, 1, 2, 3, 4};
//mystery_array_func(array, 5, 2);
//print_array(array, 5);
//mystery_array_func(array, 5, -2);
//print_array(array, 5);
//mystery_array_func(array, 3, -16);
//print_array(array, 5);
//mystery_array_func(array, 5, 127);
//print_array(array, 5);
//getchar();
//}

int main(int argc, char **argv)
{
  //char *buf = "1 2";

  //  char *p = buf;
  //  int c = 0;
  //  do
  //  {
  //    printf("%d\n", atoi(p));
  //  } while ((p = strchr(p+1,' ')) != NULL);

  char c = 127;
  c += 1;
  printf("%d\n", int(c));

  return 0;
}
