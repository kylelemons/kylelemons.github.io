#include "myLib.h"

/* Macros */
#define MAX(x,y) ((x)>(y)?(x):(y))
#define MIN(x,y) ((x)<(y)?(x):(y))
#define ABS(x)   ((x)<0?-x:x)

/* Definitions */
#define BLACK   RGB( 0, 0, 0)
#define WHITE   RGB(31,31,31)
#define RED     RGB(31, 0, 0)
#define GREEN   RGB( 0,31, 0)
#define BLUE    RGB( 0, 0,31)
#define CYAN    RGB( 0,31,31)
#define MAGENTA RGB(31, 0,31)
#define YELLOW  RGB(31,31, 0)

/* Types */
typedef struct {
  int x;
  u16 width;
  int y;
  u16 height;
  u16 color, points;
  u8  visible;
} Block;

typedef struct {
  float x, y;
} Vector;

/* Prototypes */
// Utility Functions
inline void dma(void *dst, const void *src, u32 count, u16 channel, u32 mode);
void fillScreen(u16 color);
inline u16 rotate(u16 val);
inline void pause();

// Block functions
Block newBlock(int y, int x, u16 height, u16 width, u16 color, u16 points, u8 visible);
Vector newVector(float y, float x);
inline void drawBlock(Block b);
u8 blockOverlap(Block a, Block b);

int main(void)
{
  REG_DISPCNT = BG2_ENABLE | MODE3;
  fillScreen(BLACK);
  
  // Level settings
  int block_count = 8;
  int row_count = 3;
  int spacing = 4;
  int ball_size = 3;
  int paddle_size = 30;
  int lives = 3;

  Block blocks[100];
  u16 color = RED;
  Vector ball_v = newVector( -1, 1 );
  Vector ball_pos = newVector( SCREEN_HEIGHT-10-ball_size, 10 );
  Block ball = newBlock( 0, 0, ball_size, ball_size, WHITE, 0, 1);
  Block paddle = newBlock( SCREEN_HEIGHT-4, SCREEN_WIDTH/2-paddle_size/2, 2, paddle_size, WHITE, 0, 1);
  Block score = newBlock( 0, 0, 1, 0, WHITE, 0, 1);

  // Generate Blocks
  float block_width = (SCREEN_WIDTH-spacing)/(0.+block_count) - spacing;
  int block_height = 10;
  int c, r, i = 0, t = 0;
  for (r = 0; r < row_count; ++r)
  {
    color = BLUE;
    for (t = 0; t < r; ++t) color = rotate(color);
    for (c = 0; c < block_count; ++c)
    {
      int x = (c+1)*spacing + c*block_width;
      int y = (r+1)*spacing + r*block_height;
      blocks[i++] = newBlock( y, x, block_height, block_width, color, 10-r, 1);
      color = rotate(color);
    }
  }
  
  pause();

  while(1)
  {
    /* Wait for the vertical blank period, when we can use what we just calculated */
    waitForVblank();
    if (KEY_DOWN(KEYSTART))
      pause();
    u8 drawn = 0;
    /* Draw frame (DMA makes this blindingly fast) */
    fillScreen(BLACK);
    drawBlock(ball);
    for (i = 0; i < block_count*row_count; ++i)
      if (blocks[i].visible)
      {
        drawn++;
        drawBlock(blocks[i]);
      }
    if (drawn == 0) // win!
      while (1)
      {
        fillScreen(GREEN);
        if (KEY_DOWN(KEYSTART))
          return 0;
        waitForVblank();
      }
    drawBlock(score);
    drawBlock(paddle);

    /* Calculations for next frame (utilizes redraw time) */
    // Move the ball
    ball_pos.x += ball_v.x; // floating point
    ball_pos.y += ball_v.y; // floating point
    ball.x = ball_pos.x;
    ball.y = ball_pos.y;
    
    // Collision detection
    for (i = 0; i < block_count*row_count; ++i)
    {
      if (blockOverlap(ball, blocks[i]))
      {
        score.width += blocks[i].points;
        blocks[i].visible = 0;
        ball_v.y *= -1;
        break;
      }
    }
    if (blockOverlap(ball, paddle))
    {
      ball_pos.y = MIN(ball_pos.y, paddle.y-ball.height);
      ball_v.y = -1*ABS(ball_v.y);
      if (KEY_DOWN(KEYLEFT))
        ball_v.x -= 0.5;
      if (KEY_DOWN(KEYRIGHT))
        ball_v.x += 0.5;
    }

    if (KEY_DOWN(KEYLEFT))
      paddle.x -= 2;
    if (KEY_DOWN(KEYRIGHT))
      paddle.x += 2;

    // Bounds Checking
    if (paddle.x + paddle.width >= SCREEN_WIDTH)
      paddle.x = SCREEN_WIDTH - paddle.width;
    if (paddle.x < 0)
      paddle.x = 0;

    if (ball.x + ball.width >= SCREEN_WIDTH)
    {
      //ball_pos.x = SCREEN_WIDTH - ball.width;
      ball_v.x = -1*ABS(ball_v.x);
    }
    if (ball.x <= 0)
    {
      //ball_pos.x = MAX(ball_pos.x, 0.0);
      ball_v.x = ABS(ball_v.x);
    }
    if (ball.y <= 0)
    {
      //ball_pos.y = MAX(ball_pos.y, 0.0);
      ball_v.y = ABS(ball_v.y);
    }
    if (ball.y + ball.width >= SCREEN_HEIGHT)
    {
      lives--;
      if (lives == 0)
      {
        while (1)
        {
          fillScreen(RED);
          if (KEY_DOWN(KEYSTART))
            return 0;
          waitForVblank();
        }
      }
      else
      {
        ball_pos.x = 10;
        ball_pos.y = SCREEN_HEIGHT-10-ball_size;
        ball_v.x = 1;
        ball_v.y = -1;
      }
    }


  }

  return 0;
}

// Utility Functions
void fillScreen(u16 color)
{
  // fillScreenDMA3(color);
  u32 mode = DMA_SRC_FIXED | DMA_16 | DMA_ON;
  dma(videoBuffer, &color, 160*240, 3, mode);
}

inline void dma(void *dst, const void *src, u32 count, u16 channel, u32 mode)
{
  if (count == 0)
    return;
  /* You'll understand this when you learn about structs and arrays */
  DMA_MEM[channel].cnt = 0;
  DMA_MEM[channel].src = src;
  DMA_MEM[channel].dst = dst;
  DMA_MEM[channel].cnt = count | mode;
}

inline u16 rotate(u16 val)
{
  return (val << 1) | (val >> 15);
}

inline void pause()
{
  if (KEY_DOWN(KEYSTART)) // debounce a start condition
    while (KEY_DOWN(KEYSTART));
  while (!KEY_DOWN(KEYSTART));
  while (KEY_DOWN(KEYSTART));
}

// Vector constructor
Vector newVector(float y, float x)
{
  Vector v = {x, y};
  return v;
}

// Block functions
Block newBlock(int y, int x, u16 height, u16 width, u16 color, u16 points, u8 visibility)
{
  Block b = {x, width, y, height, color, points, visibility};
  return b;
}

inline void drawBlock(const Block b)
{
  u16 *start;
  int i;
  for(i = 0; i < b.height; i++)
  {
    start = videoBuffer + ( (b.y+i)*240 + b.x );
    dma(start, &b.color, b.width, 3, DMA_SRC_FIXED | DMA_16 | DMA_ON);
  }
}

u8 blockOverlap(Block a, Block b)
{
  return ( a.visible && b.visible
        && (b.x - a.width  <= a.x && a.x <= b.x + b.width)
        && (b.y - a.height <= a.y && a.y <= b.y + b.height) );
}

/* END OF FILE */
