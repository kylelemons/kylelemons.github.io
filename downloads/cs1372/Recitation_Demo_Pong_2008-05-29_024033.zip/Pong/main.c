// The Main HAM Library
#include "myLib.h"
#include <math.h>

#define BOUND_LEFT   0
#define BOUND_TOP    0
#define BOUND_RIGHT  (SCREEN_WIDTH-0)
#define BOUND_BOTTOM (SCREEN_HEIGHT-0)

#define MAX(x,y) (((x)>(y))?(x):(y))
#define MIN(x,y) (((x)>(y))?(y):(x))
#define INB(x,y,z) ((x)<=(y)&&(y)<(z))

/*
  x = C?a:b;
  if (C)
    x = a;
  else
    x = b;
*/

// Utility
void reflect(float *pos, float *veclocity, float barrier);
void pause();

// Drawing
void drawPaddle(int py, int px, int ps, u16 col);
void drawBall(int by, int bx, int br, u16 col);

// Collision detection
int paddleCollision(int py, int px, int ps, int by, int bx, int br);
int wallCollision(int by, int bx, int br);
int goalCollision(int by, int bx, int br);
int loseCollision(int by, int bx, int br);

// End Game Routines
void fill(u16 color);

// Function: main()
int main()
{
    //ham_Init();
    // Constants
    static u16 red   = RGB(31,0,0);
    static u16 green = RGB(0,31,0);
    static u16 blue  = RGB(0,0,31);
    static u16 white = RGB(31,31,31);
    static u16 black = RGB(0,0,0);
    // Difficulty Settings
    static float human_speed = 1.5;  // human paddle move
    static float speed_boost = 1.01; // speed multiplier on bounce
    static float comp_reflex = 1.5;  // max computer paddle move
    static int   pad_penalty = 2;    // pixels to shave/add
    static float ball_spin_v = 0.5;  // velocity to use when "spinning"
    static float terminal_vy = 3;    // terminal y velocity
    
    // Position
    float p1x = 2;
    float p1y = SCREEN_HEIGHT/2;
    float p2x = SCREEN_WIDTH-1-2;
    float p2y = SCREEN_HEIGHT/2;
    float bx  = rand()%100 + 20;
    float by  = rand()%100 + 20;
    // Velocity
    float vx  = 1;
    float vy  = -1;
    // Sizes
    int p1s   = 20;
    int p2s   = 20;
    int br    = 2;

    // Colors
    u16 ball_color = white;
    u16 bg_color = black;
    u16 p1_color = white;
    u16 p2_color = white;

    REG_DISPCNT = BG2_ENABLE | MODE3;
    
    pause();
  
    while (p1s > 0 && p2s > 0)
    {
        
      if (KEY_DOWN(KEYSTART))
        pause();
        
      //drawBall(by, bx, br, bg_color);
      //drawPaddle(p1y, p1x, p1s, bg_color);
      //drawPaddle(p2y, p2x, p2s, bg_color);

      // Maximum Velocity
      vx = MAX(MIN(vx, br),-br);
      vy = MAX(MIN(vy, terminal_vy),-terminal_vy);
      // Position update
      bx += vx;
      by += vy;
      // Keep paddle on screen
      
      p2y += MAX(MIN(by-p2y,comp_reflex),-comp_reflex);
      
      if (paddleCollision(p1y, p1x, p1s, by, bx, br))
      {
        // Human player
        reflect(&bx, &vx, p1x+br);
        // Speed up a little bit
        vx *= speed_boost;
        vy *= speed_boost;
        if (KEY_DOWN(KEYUP))
          vy -= ball_spin_v;
        if (KEY_DOWN(KEYDOWN))
          vy += ball_spin_v;
      }
      else if (paddleCollision(p2y, p2x, p2s, by, bx, br))
      {
        reflect(&bx, &vx, p2x-br);
      }
      else if (wallCollision(by, bx, br))
      {
        if (vy > 0) // moving down
          reflect(&by, &vy, SCREEN_HEIGHT-1-br);
        else // moving up
          reflect(&by, &vy, 0+br);
      }
      else if (goalCollision(by, bx, br))
      {
        p1s += pad_penalty;
        p2s -= pad_penalty;
        vx *= -1;
        vy *= 0.5;
        by = rand()%100 + 20;
        bx = SCREEN_WIDTH - rand()%100 - 20;
      }
      else if (loseCollision(by, bx, br))
      {
        p1s -= pad_penalty;
        p2s += pad_penalty;
        vx *= -1;
        vy *= 0.5;
        by = rand()%100 + 20;
        bx = rand()%100 + 20;
      }
      
      if (KEY_DOWN(KEYUP) && (p1y-p1s/2-human_speed >= 0))
        p1y -= human_speed;
      if (KEY_DOWN(KEYDOWN) && (p1y+p1s/2+human_speed < SCREEN_HEIGHT))
        p1y += human_speed;
      if (KEY_DOWN(KEYL) && p1s < SCREEN_HEIGHT/2)
        p1s += 1;
      if (KEY_DOWN(KEYR) && p1s > 10)
        p1s -= 1;
        
      p1y = MAX(MIN(p1y, SCREEN_HEIGHT-p1s/2),p1s/2);
      p2y = MAX(MIN(p2y, SCREEN_HEIGHT-p2s/2),p2s/2);

      // Set the new field
      int count;
      for (count = 0; count <= 0; ++count)
        waitForVblank();
      fill(bg_color);
      drawPaddle(p1y, p1x, p1s, p1_color);
      drawPaddle(p2y, p2x, p2s, p2_color);
      drawBall((int)by, (int)bx, br, ball_color);
      
      // draw dividing line
      for (count = 0; count < SCREEN_HEIGHT; ++count)
        if ((count+5)/10 % 2 == 1)
          setPixel3(count, SCREEN_WIDTH/2, ball_color);
      
    }
    
    if (p1s > 0)
      fill(green);
    else
      fill(red);

    return 0;
} // End of main()


// Utility
void reflect(float *pos, float *velocity, float barrier)
{
  float part = (*pos - barrier) / *velocity;
  *pos -= *velocity * part;
  *velocity *= -1;
  *pos += *velocity * part;
}

void pause()
{
  while(KEY_DOWN(KEYSTART));
  while(!KEY_DOWN(KEYSTART));
  while(KEY_DOWN(KEYSTART));
}

// Drawing
void drawPaddle(int py, int px, int ps, u16 col)
{
  fillRectDMA3(py-ps/2, px, ps, 1, col);
}

void drawBall(int by, int bx, int br, u16 col)
{
  u16 bgcol = videoBuffer[OFFSET3((int)by,(int)bx)];
  fillRectDMA3(by-br, bx-br, br*2+1, br*2+1, col);
  br--;
  fillRectDMA3(by-br, bx-br, br*2+1, br*2+1, bgcol);
}

// Collision detection
int paddleCollision(int py, int px, int ps, int by, int bx, int br)
{
  // check if ball is vertically aligned with the paddle
  if (by+br >= py-ps/2 && by-br <= py+ps/2)
  {
    // check if ball is horizontally intersecting the ball
    if (bx-br <= px && px <= bx+br)
      return 1;
  }
  return 0;
}

int wallCollision(int by, int bx, int br)
{
  return (by - br < 0 || by + br >= SCREEN_HEIGHT);
}

int goalCollision(int by, int bx, int br)
{
  return (bx + br >= SCREEN_WIDTH);
}

int loseCollision(int by, int bx, int br)
{
  return (bx - br < 0);
}

// End Game Routines
void fill(u16 col)
{
  volatile u16 c = col;
  fillScreenDMA3(c);
}
