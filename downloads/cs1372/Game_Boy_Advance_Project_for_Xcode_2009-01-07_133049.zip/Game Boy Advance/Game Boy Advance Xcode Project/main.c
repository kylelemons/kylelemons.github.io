/*
 *  main.c
 *  Game Boy Advance
 *
 *  Created by Tim Omernick on 8/18/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#define MULTIBOOT 1
#if MULTIBOOT
    int __gba_multiboot;
#endif

// Display control register
#define REG_DISPCNT *(unsigned int *)0x04000000

// VRAM
#define VRAM ((unsigned short *)0x06000000)

// Screen size
#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 160

void fillRect(unsigned int minX, unsigned int minY, unsigned int width, unsigned int height, unsigned short color)
{
    unsigned int maxX = minX + width;
    unsigned int maxY = minY + height;
    unsigned int x;
    
    for (x = minX; x < maxX; x++) {
        unsigned int y;
        
        for (y = minY; y < maxY; y++) {
            VRAM[x + y * SCREEN_WIDTH] = color;
        }
    }
}

int main(void)
{
    // Set video mode to 3 (240x160, 16bpp, no page flipping).  Enable background 0.
    REG_DISPCNT = 0x0403;

    // Draw a red square
    fillRect(10, 10, 50, 50, 0x001f);

    // Draw a green square
    fillRect(70, 10, 50, 50, 0x03e0);

    // Draw a blue square
    fillRect(130, 10, 50, 50, 0x7c00);
    
    // A GBA program should never end
    while(1) {};

    return 0;
}
