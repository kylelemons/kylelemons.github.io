#pragma once

char *fileRead(FILE *fIn);
void split(char* tosplit, char* delim, char ***parsed, int* len);
void freesplit(char ***parsed, int strings);
double average(double *pdData, int points);