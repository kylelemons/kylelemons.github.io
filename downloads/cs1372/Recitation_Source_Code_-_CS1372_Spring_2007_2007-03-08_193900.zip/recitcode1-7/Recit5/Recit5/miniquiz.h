#pragma once

int *arrayMax(int *pirgArray, int iElements);