#include <stdio.h>

void lookAt(int *pirgArray, int iElements)
{
  for (int i = 0; i < iElements; ++i)
  {
    int iVal;
    iVal = *(pirgArray + i); //same as pirgArray[i]
                            //*pirgArray == pirgArray[0]
    printf( "array[%2d] = %d\n", i, iVal);
  }
}

// Rotate drgArray iOffset spaces (wrapping around)
void rotate(int *pirgArray, int iElements, int iOffset)
{
  int iTemp; // store the first value
  int iIndex, iDest;
  for (int o = 0; o < iOffset; ++o)
  {
    iTemp = *pirgArray;
    for (int i = 1; i < iElements; ++i)
    {
      iIndex = i;
      iDest = i-1;
      pirgArray[iDest] = pirgArray[iIndex];
    }
    pirgArray[iElements - 1] = iTemp;  
  }
}