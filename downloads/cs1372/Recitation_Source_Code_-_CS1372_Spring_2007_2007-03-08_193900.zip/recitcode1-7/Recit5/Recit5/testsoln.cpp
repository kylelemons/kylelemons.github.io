#include <stdio.h>
#include <math.h>

int fact(int iNum)
{
  int iVal = 1;
  for (int i = 1; i <= iNum; ++i)
    iVal *= i;
  return iVal;
}

// Problem 3

double sin_taylor(double dTheta, int iDegree)
{
	double sum = 0;
	for (int i = 0; i <= iDegree; ++i)
	{
		sum += ( pow(-1.0,i) / fact( 2*i + 1 ) )
           * pow( dTheta, ( 2*i + 1 ) );
	}
	return sum;
}

// Problem 4

void rotate( int *piA, int *piB, int *piC )
{
  int iTempA, iTempB, iTempC;

  iTempA = *piA;
  iTempB = *piB;
  iTempC = *piC;

  *piA = iTempC;
  *piB = iTempA;
  *piC = iTempB;
}