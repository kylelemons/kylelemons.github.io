#pragma once

void lookAt( int*, int );

void rotate(int *pdrgArray, int iElements, int iOffset);