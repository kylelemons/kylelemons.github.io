#include <stdio.h>
#include "miniquiz.h"
#include "testsoln.h"
#include "recit5.h"

int main()
{
	int irgArray[] = {3, 7, 9, 12, 2, -1, 4, 1, 1, 3};

	int *piMax = arrayMax( irgArray, sizeof(irgArray)/sizeof(int) );
	printf( "Max value is %d\n", *piMax );

  printf("Before rotate:\n");
  lookAt(irgArray, sizeof(irgArray)/sizeof(int));
  rotate(irgArray, sizeof(irgArray)/sizeof(int), 5);

  printf("After rotate:\n");
  lookAt(irgArray, sizeof(irgArray)/sizeof(int));

  /* Test problem 3
  int a=2, b=3, c=4;
  rotate( &a, &b, &c );
  printf("%d, %d, %d\n", a, b, c);
  */

#ifdef _DEBUG
	getchar();
#endif

	return 0;
}