#include <stdio.h>

int *arrayMax(int *pirgArray, int iElements)
{
	int iIdx = 0;
	for (int i = 0; i < iElements; ++i)
	{
		if (pirgArray[i] > pirgArray[iIdx])
			iIdx = i;
	}
	return pirgArray+iIdx;
}