// Recit2b.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include "myFuncs.h"
#include "myFuncs.h"

int main(int argc, char** argv)
{

  int iAnswer   = 7*8;
  int iQuestion = 42;

  swap(&iQuestion, &iAnswer);

  count();

  printf("The Answer to the Ultimate Question of Life, the Universe, and Everything is...\n");
  getchar();
  printf("Answer: %d\n", iAnswer);
  printf("Question: %d\n", iQuestion);

  getchar();

	return 0;
}