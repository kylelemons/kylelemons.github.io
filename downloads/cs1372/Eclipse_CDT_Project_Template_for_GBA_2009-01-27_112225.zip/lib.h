/*
 *  lib.h
 *  Game Boy Advance
 *
 *  Template GBA Project for CS1372
 *  Created January 27, 2009
 *
 */

// Definitions and prototypes for the game boy

#define MULTIBOOT 1
#if MULTIBOOT
int __gba_multiboot;
#endif

// Display control register
#define REG_DISPCNT (*(unsigned int *)0x04000000)

// VRAM
#define VRAM ((unsigned short *)0x06000000)

// Screen size
#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 160

// Video modes
//   Set video mode to 3 (240x160, 16bpp, no page flipping).  Enable background 0.
#define MODE_3 0x0403

// Macros
#define COLOR(r,g,b) ( (r & 0x1F) | (g & 0x1F) << 5 | (b & 0x1F) << 10 )
#define XYPOS(x,y) ( (y) * SCREEN_WIDTH + (x) )
#define RCPOS(r,c) ( (r) * SCREEN_WIDTH + (c) )

// Types
typedef unsigned short u16;

// Prototypes

/** Create a horizontal line on row, starting at col, that is width pixels wide.
 * Note that this does NOT do bounds checking on the screen!
 * @param row The row on which to draw the line
 * @param col The column on which to start drawing
 * @param width The number of pixels to draw
 * @param color The color to draw
 */
void hline(int row, int col, int width, u16 color);

/** Create a vertical line at rc(row,col) of height pixels with color color
 * Note that this does NOT do bounds checking on the screen!
 * @see ::hline
 */
void vline(int row, int col, int height, u16 color);

/** Draw the boundary OUTSIDE the given box.
 * Note that this does NOT do bounds checking on the screen!
 * @param row The start row of the inner box
 * @param col The start col of the inner box
 * @param height The number of rows of the inner box
 * @param width The number of columns of the inner box
 * @param color The color to draw
 */
void boundary(int row, int col, int height, int width, u16 color);
void thickboundary(int row, int col, int height, int width, u16 color, int borderwidth);

/** Fill the given rectangle from (row,col) that is height pixels tall and width pixels wide
 * Note that this does NOT do bounds checking on the screen!
 * @param row The start row of the box
 * @param col The start column of the box
 * @param height The number of rows of the box
 * @param width The number of columns of the box
 * @param color The color to fill the box
 */
void fill(int row, int col, int height, int width, u16 color);
