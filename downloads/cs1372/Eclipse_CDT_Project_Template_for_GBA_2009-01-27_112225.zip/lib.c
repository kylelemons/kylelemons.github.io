/*
 *  lib.c
 *  Game Boy Advance
 *
 *  Template GBA Project for CS1372
 *  Created January 27, 2009
 *
 */

#include "lib.h"

void hline(int row, int col, int width, u16 color)
{
  int i;
  for (i = 0; i < width; ++i)
    VRAM[RCPOS(row, col+i)] = color;
}

void vline(int row, int col, int height, u16 color)
{
  int i = 0;
  for (i = 0; i < height; ++i)
    VRAM[RCPOS(row+i, col)] = color;
}

void boundary(int row, int col, int height, int width, u16 color)
{
  // Upper boundary
  hline(row-1, col-1, width+1, color);
  // Left boundary
  vline(row, col-1, height+1, color);
  // Lower boundary
  hline(row+height, col, width+1, color);
  // Right boundary
  vline(row-1, col+width, height+1, color);
}

void thickboundary(int row, int col, int height, int width, u16 color, int borderwidth)
{
	int i;
  for (i = 0; i < borderwidth; ++i)
  {
    boundary(row-i, col-i, height+2*i, width+2*i, color);
  }
}

void fill(int row, int col, int height, int width, u16 color)
{
  int i;
  for (i = 0; i < height; ++i)
  	hline(row+i, col, width, color);
}
