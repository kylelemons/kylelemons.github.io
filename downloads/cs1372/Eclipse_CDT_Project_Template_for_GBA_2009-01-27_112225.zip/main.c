/*
 *  main.c
 *  Game Boy Advance
 *
 *  Template GBA Project for CS1372
 *  Created January 27, 2009
 *
 */

#include "lib.h"

int main(void)
{
  REG_DISPCNT = MODE_3;

  int row = 30;
  int col = 30;
  int width = 25;
  int height = 80;
  u16 bordercolor = COLOR(31,31,31);
  u16 fillcolor = COLOR(31,0,0);

  boundary(row, col, height, width, bordercolor);
  fill(row, col, height, width, fillcolor);

  // A GBA program should never end
  while(1) {};

  return 0;
}
