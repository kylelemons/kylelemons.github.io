// testConsole.cpp : Defines the entry point for the console application.
//

#include "testConsole.h"
#include "matrix.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>

#ifdef _DEBUG
#include "leaks.h"
FILE *debug;
#endif

/*
  Miniquiz:

  Write a function call vReverse that consumes an sVector with fields:
           int length;
           double *data;
  and returns a new sVector with the data reversed.
*/

sVector vReverse(sVector v) {
  sVector res = v;
  res.data = (double *) malloc(v.length * sizeof(double));
  for(int i = 0; i < v.length; i++) {
    res.data[i] = v.data[v.length-1-i];
  }
  return res;
}

// x = 1:5
// y = -x(1:4)
//   x
//     -1  -2  -3  -4

sVector vIndex(sVector vSrc, sVector vIndices)
{
  sVector vNew = build(vIndices);
  for ( int i = 0 ; i < vIndices.length ; ++i )
  {
    if (vIndices.data[i] < vSrc.length && vIndices.data[i] >= 0)
      vNew.data[i] = vSrc.data[ int(vIndices.data[i]) - 1 ];
    else
      vNew.data[i] = 0;
  }
  return vNew;
}

int main(int argc, char* argv[])
{
#ifdef _DEBUG
#include "leaks.cpp"
	debug = fopen("debug.log","w");
#endif

  sVector vCountUp = colon(1,10);
  sVector vCountId = colon(1,4);
  sVector vCountSh = vIndex(vCountUp, vCountId);
  sVector vCountDn = vReverse(vCountUp);

  print(stdout, "vCountUp", vCountUp);
  print(stdout, "vCountDn", vCountDn);
  print(stdout, "vCountSh", vCountSh);
  vfree(vCountDn);

  vCountDn = vReverse(vCountUp);
  print(stdout, "vCountDn", vCountDn);

  vfree(vCountUp);
  vfree(vCountDn);
  vfree(vCountId);
  vfree(vCountSh);

#ifdef _DEBUG
	fflush(debug);
	fclose(debug); 
	getchar();
#endif
	return 0;
}
