// IO Parameters
void separate(  double dInput,
                int    *piWholePart,
                double *pdFracPart,
                bool   *pbPositive
                );
// Scope

void scopeDemo();