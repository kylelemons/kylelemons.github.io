#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "data.h"

int main(int argc, char **argv)
{
#ifndef _GENERATE
  int iPoints = 0;
  double *pdData1;
  double *pdData2;
  double *pdData3;

  FILE *fIn = fopen("experiment.dat", "r");
  char *rawdata = fileRead(fIn);
  fclose(fIn);

  char **ppcLines;
  int iLineCount;
  // Split the raw data into lines
  split(rawdata, "\n", &ppcLines, &iLineCount);
  // Allocate the memory for data
  pdData1 = (double*)calloc(iLineCount,sizeof(double));
  pdData2 = (double*)calloc(iLineCount,sizeof(double));
  pdData3 = (double*)calloc(iLineCount,sizeof(double));
  // For each line
  for (int i = 0; i < iLineCount; ++i)
  {
    if (strlen(ppcLines[i]) <= 0) // Ignore blank lines
      continue; // skip to next loop
    //printf("%s\n", ppcLines[i]);
    char **ppcWords;
    int iWordCount;
    // Split the line into "words"
    split(ppcLines[i], " ", &ppcWords, &iWordCount);
    // Convert into int/float
    int iSample = atoi(ppcWords[0]);
    double dValue1 = atof(ppcWords[1]);
    double dValue2 = atof(ppcWords[2]);
    double dValue3 = atof(ppcWords[3]);
    // Store into array(s)
    //printf("%d: %f %f %f\n", iSample, dValue1, dValue2, dValue3);
    pdData1[iSample] = dValue1;
    pdData2[iSample] = dValue2;
    pdData3[iSample] = dValue3;
    // Free the split line
    freesplit(&ppcWords, iWordCount);
    if (iSample > iPoints) iPoints = iSample; // Sample is zero indexed
  }
  // Output the five-point rolling average
#define ROLL 5
  double pdrgRolling1[ROLL];
  double pdrgRolling2[ROLL];
  double pdrgRolling3[ROLL];
  // Zero the rolling arrays
  for (int i = 0; i < ROLL; ++i)
    pdrgRolling1[i] = pdrgRolling2[i] = pdrgRolling3[i] = 0.0;
  for (int i = 0; i <= iPoints; ++i)
  {
    // Store the data
    pdrgRolling1[ i%ROLL ] = pdData1[i];
    pdrgRolling2[ i%ROLL ] = pdData2[i];
    pdrgRolling3[ i%ROLL ] = pdData3[i];
    // Average the data and put it back
    pdData1[i] = average(pdrgRolling1, ROLL);
    pdData2[i] = average(pdrgRolling2, ROLL);
    pdData3[i] = average(pdrgRolling3, ROLL);
    // Print the averages
    printf("%3d %10.3f %10.3f %10.3f\n", i, pdData1[i], pdData2[i], pdData3[i]);
  }
  // Free the split data
  freesplit(&ppcLines, iLineCount);
  // Free the raw data
  free(rawdata);

#else
  const float rmax = 1.0;
  FILE *fOut = fopen("experiment.dat", "w");
  
  int time;
  double dp1, dp2, dp3;  
  for (int i = 0; i < 1000; ++i)
  {
    time = i;
    // First data point
    //  y = x          + r
    dp1 = time + ( double(rand())/RAND_MAX * rmax ) - (rmax/2);
    // Second data point
    //  y = (x-500)^2  + r
    dp2 = pow(double(time-500), 2) + ( double(rand())/RAND_MAX * rmax ) - (rmax/2);
    // Third data point
    //  y = sin(x)     + r
    dp3 = sin(double(time)/200)*5.0 + ( double(rand())/RAND_MAX * rmax ) - (rmax/2);
    fprintf(fOut, "%d %f %f %f\n", time, dp1, dp2, dp3);
  }
  fclose(fOut);
#endif

#ifdef _DEBUG
  getchar();
#endif

  return 0;
}