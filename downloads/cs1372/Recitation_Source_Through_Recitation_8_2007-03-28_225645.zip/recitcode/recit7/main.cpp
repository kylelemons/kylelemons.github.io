#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <string.h>
#include "codecrack.h"
#include "filecrap.h"
#include "vigenere.h"

#define INTERACTIVE

int main(int argc, char **argv)
{
#ifdef INTERACTIVE
  char *str = (char *)malloc(1024);
  do
  {
    printf("Message:      ");
    fgets(str, 1024, stdin);
    for (char *c = str; *c; ++c)
      if (*c == '\n')
        *c = '\0';
    if (strlen(str) <= 0)
      break;
    printf("Key:          ");
    char *key = (char *)malloc(1024);
    fgets(key, 1024, stdin);
    for (char *c = key; *c; ++c)
      if (*c == '\n')
        *c = '\0';
    char *enc = (char *)calloc(strlen(str)+1,sizeof(char));
    encrypt(str,key,str);
    printf("Encrypted:    %s\n", str);
  } while (str);
#else
  gen();
  FILE *fin = fopen("secure.txt", "r");
  if (fin == NULL || ferror(fin))
  {
    perror("Error opening file");
    exit(1);
  }
  char *fileData = readFile(fin);
  fclose(fin);

  char **lines;
  int linecount;

  split(fileData, "\n", &lines, &linecount);

  SCrackStats stats;
  for (unsigned k = 0; k < 256; ++k)
    stats.key[k] = 0;

  char *p = lines[0];  
  for (int i = 0; i < linecount; ++i)
  {
    if (strlen(lines[i]) <= 1)
      continue;
    
    // Zero out the key counters
    for (unsigned k = 0; k < 256; ++k)
      stats.key[k] = 0;
    
    SMessage w;
    w.encrypted = lines[i];
    w.decrypted = NULL;
    w.len = (unsigned)strlen(lines[i]);
    w.beg = 0;
    stats.message = &w;

    char *colon = strchr(w.encrypted, ':');
    if (colon != NULL)
      w.beg = (unsigned)(colon - w.encrypted + 2);

    analyze(&stats);
    printf("%s\n", w.decrypted);
  }

  freesplit(&lines, linecount);
#endif

#ifdef _DEBUG
  getchar();
#endif
  return 0;
}