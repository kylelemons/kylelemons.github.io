#ifndef MYFUNCS_H
#define MYFUNCS_H

void swap( int* piA, int* piB );

void swap2( int iA, int iB );

void count();

#endif