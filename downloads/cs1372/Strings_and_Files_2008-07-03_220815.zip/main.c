#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MEM_INC 256

int main(int argc, char *argv[])
{
  FILE *in = fopen("input.txt", "r");
  FILE *out;
  char *p;
  int c;
  
  int lc = 0;
  char **lines = NULL;
  int begin = 0;
  
  int length = 0;
  char *fileContents = NULL;
  int i = 0;
  
  while (!feof(in))
  {
    c = fgetc(in);
    if (c == EOF) break;
    
    if (i >= length)
    {
      fileContents = (char*)realloc(fileContents, length+MEM_INC+1);
      length += MEM_INC;
    }
    fileContents[i++] = c;
    fileContents[i] = '\0';
    printf("Read: (%d) %s\n", length, fileContents);
  }
  fclose(in);
  
  for (i = 0; i < (signed)strlen(fileContents); ++i)
  {
    if (fileContents[i] == '\n' || fileContents[i] == '\r')
    {
      int len = i - begin;
      lines = (char**)realloc(lines, (lc+1)*sizeof(char*));
      lines[lc] = (char*)calloc(len+1,1);
      memcpy(lines[lc], fileContents+begin, len);
      printf("Line %d: %s\n", lc+1, lines[lc]);
      lc++;
      begin = i;
      while (fileContents[begin] == '\n' || fileContents[begin] == '\r' && begin < (signed)strlen(fileContents))
        begin++;
    }
  }
  
  out = fopen("output.txt", "w");
  for (p = fileContents; *p; ++p)
  {
    c = *p;
    if (islower(c))
      c = 'z'-c+'a';
    if (isupper(c))
      c = 'Z'-c+'A';
    printf("%c", c);
    fputc(c, out);
  }
  fclose(out);

  system("PAUSE");
  return EXIT_SUCCESS;
}
